enum ClientCategory {
  magasin('Magasin'),
  tousDepots('Tous Dépôts');

  const ClientCategory(this.label);
  final String label;
}