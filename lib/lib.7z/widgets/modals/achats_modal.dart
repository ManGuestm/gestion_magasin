import 'dart:async';

import 'package:drift/drift.dart' hide Column;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';

import '../../constants/app_functions.dart';
import '../../database/database.dart';
import '../../database/database_service.dart';
import '../../services/achat_service.dart';
import '../../utils/cmup_calculator.dart';
import '../../utils/date_utils.dart' as app_date;
import '../../utils/number_utils.dart';
import '../../utils/stock_converter.dart';
import '../common/article_navigation_autocomplete.dart';
import '../common/enhanced_autocomplete.dart';
import '../common/tab_navigation_widget.dart';
import 'achats_intents.dart';
import 'add_fournisseur_modal.dart';
import 'bon_reception_preview.dart';

class AchatsModal extends StatefulWidget {
  const AchatsModal({super.key});

  @override
  State<AchatsModal> createState() => _AchatsModalState();
}

class _AchatsModalState extends State<AchatsModal> with TabNavigationMixin {
  final DatabaseService _databaseService = DatabaseService();
  final AchatService _achatService = AchatService();
  final GlobalKey<ScaffoldMessengerState> _scaffoldMessengerKey = GlobalKey<ScaffoldMessengerState>();

  // Focus node pour les raccourcis globaux
  late final FocusNode _globalShortcutsFocusNode;

  // Focus nodes
  late final FocusNode _nFactFocusNode;
  late final FocusNode _fournisseurFocusNode;
  late final FocusNode _articleFocusNode;
  late final FocusNode _uniteFocusNode;
  late final FocusNode _quantiteFocusNode;
  late final FocusNode _prixFocusNode;
  late final FocusNode _depotFocusNode;
  late final FocusNode _validerFocusNode;
  late final FocusNode _annulerFocusNode;
  late final FocusNode keyboardFocusNode;
  late final FocusNode _searchAchatsFocusNode;
  late final FocusNode _echeanceJoursFocusNode;

  // Timer pour maintenir le focus global
  Timer? _globalFocusTimer;

  // Controllers
  final TextEditingController _numAchatsController = TextEditingController();
  final TextEditingController _nFactController = TextEditingController();
  final TextEditingController _dateController = TextEditingController();
  final TextEditingController _fournisseurController = TextEditingController();
  final TextEditingController _modePaiementController = TextEditingController();
  final TextEditingController _echeanceController = TextEditingController();

  final TextEditingController _totalTTCController = TextEditingController();
  final TextEditingController _totalFMGController = TextEditingController();
  final TextEditingController _articleSearchController = TextEditingController();
  TextEditingController? _autocompleteController;
  final TextEditingController _uniteController = TextEditingController();
  final TextEditingController _depotController = TextEditingController(text: 'MAG');
  final TextEditingController _quantiteController = TextEditingController();
  final TextEditingController _prixController = TextEditingController();
  final TextEditingController _searchAchatsController = TextEditingController();
  final TextEditingController _echeanceJoursController = TextEditingController();

  // Lists
  List<Frn> _fournisseurs = [];
  List<Article> _articles = [];
  List<String> _depots = [];
  List<MpData> _modesPaiement = [];
  final List<Map<String, dynamic>> _lignesAchat = [];

  // Selected values
  String? _selectedFournisseur;
  String? _selectedModePaiement;
  Article? _selectedArticle;
  String? _selectedUnite;
  String? _selectedDepot = 'MAG';
  bool _isExistingPurchase = false;
  int? _selectedRowIndex;
  String _selectedFormat = 'A6';
  SocData? _societe;
  bool _isModifyingArticle = false;
  Map<String, dynamic>? _originalArticleData;
  List<String> _achatsNumbers = [];
  final Map<String, String> _achatsStatuts = {}; // Nouveau: pour stocker les statuts
  int currentAchatIndex = -1;
  String _searchAchatsText = '';
  String _selectedStatut = 'Brouillard';
  String? _statutAchatActuel;

  List<String> _getBrouillardAchats() {
    return _achatsNumbers.where((numAchat) {
      final statut = _achatsStatuts[numAchat] ?? 'BROUILLARD';
      final matchesSearch = _searchAchatsText.isEmpty || numAchat.toLowerCase().contains(_searchAchatsText);
      return statut == 'BROUILLARD' && matchesSearch;
    }).toList();
  }

  List<String> _getJournalAchats() {
    return _achatsNumbers.where((numAchat) {
      final statut = _achatsStatuts[numAchat] ?? 'BROUILLARD';
      final matchesSearch = _searchAchatsText.isEmpty || numAchat.toLowerCase().contains(_searchAchatsText);
      return statut == 'JOURNAL' && matchesSearch;
    }).toList();
  }

  List<String> _getContrePasseAchats() {
    return _achatsNumbers.where((numAchat) {
      final statut = _achatsStatuts[numAchat] ?? 'BROUILLARD';
      final matchesSearch = _searchAchatsText.isEmpty || numAchat.toLowerCase().contains(_searchAchatsText);
      return statut == 'CONTRE-PASSé' && matchesSearch;
    }).toList();
  }

  @override
  void initState() {
    super.initState();

    // Initialiser le focus node pour les raccourcis globaux
    _globalShortcutsFocusNode = FocusNode(
      debugLabel: 'GlobalShortcutsFocusNode',
      canRequestFocus: true,
      skipTraversal: true,
    );

    // Initialize focus nodes with tab navigation
    _nFactFocusNode = createFocusNode();
    _fournisseurFocusNode = createFocusNode();
    _articleFocusNode = createFocusNode();
    _uniteFocusNode = createFocusNode();
    _quantiteFocusNode = createFocusNode();
    _prixFocusNode = createFocusNode();
    _depotFocusNode = createFocusNode();
    _validerFocusNode = createFocusNode();
    _annulerFocusNode = createFocusNode();
    keyboardFocusNode = createFocusNode();
    _searchAchatsFocusNode = createFocusNode();
    _echeanceJoursFocusNode = createFocusNode();

    // Listeners pour les champs d'échéance
    _dateController.addListener(_onDateChanged);
    _echeanceJoursController.addListener(_onEcheanceJoursChanged);

    _autocompleteController = TextEditingController();
    _loadData();
    _loadAchatsNumbers().then((_) => _initializeForm());

    // Ajouter des listeners pour les focus nodes
    _validerFocusNode.addListener(() {
      if (mounted) setState(() {});
    });
    _annulerFocusNode.addListener(() {
      if (mounted) setState(() {});
    });

    // Focus automatique sur le KeyboardListener pour capturer les raccourcis
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _globalShortcutsFocusNode.requestFocus();
    });

    // S'assurer que les raccourcis globaux restent actifs
    _globalFocusTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (!mounted) {
        timer.cancel();
        return;
      }
      if (!_globalShortcutsFocusNode.hasFocus && !_globalShortcutsFocusNode.hasPrimaryFocus) {
        _ensureGlobalShortcutsFocus();
      }
    });
  }

  void _onDateChanged() {
    if (_dateController.text.isNotEmpty) {
      _calculerEcheanceDepuisDate();
    }
  }

  void _onEcheanceJoursChanged() {
    if (_echeanceJoursController.text.isNotEmpty) {
      _calculerEcheanceDepuisJours();
    }
  }

  void _calculerEcheanceDepuisDate() {
    try {
      final dateParts = _dateController.text.split('-');
      if (dateParts.length == 3) {
        final dateFacture = DateTime(
          int.parse(dateParts[2]),
          int.parse(dateParts[1]),
          int.parse(dateParts[0]),
        );

        final joursEcheance = int.tryParse(_echeanceJoursController.text) ?? 7;
        final dateEcheance = dateFacture.add(Duration(days: joursEcheance));

        setState(() {
          _echeanceController.text = app_date.AppDateUtils.formatDate(dateEcheance);
        });
      }
    } catch (e) {
      // Ignorer les erreurs de parsing
    }
  }

  void _calculerEcheanceDepuisJours() {
    try {
      final dateParts = _dateController.text.split('-');
      if (dateParts.length == 3) {
        final dateFacture = DateTime(
          int.parse(dateParts[2]),
          int.parse(dateParts[1]),
          int.parse(dateParts[0]),
        );

        final joursEcheance = int.tryParse(_echeanceJoursController.text) ?? 7;
        final dateEcheance = dateFacture.add(Duration(days: joursEcheance));

        setState(() {
          _echeanceController.text = app_date.AppDateUtils.formatDate(dateEcheance);
        });
      }
    } catch (e) {
      // Ignorer les erreurs de parsing
    }
  }

  void _initializeForm() async {
    // Toujours créer un nouveau formulaire par défaut
    final now = DateTime.now();
    _dateController.text = app_date.AppDateUtils.formatDate(now);

    // échéance par défaut : 7 jours après la date de facturation
    final echeanceDefaut = now.add(const Duration(days: 7));
    _echeanceController.text = app_date.AppDateUtils.formatDate(echeanceDefaut);
    _echeanceJoursController.text = '7';

    // Générer le prochain numéro d'achat
    final nextNum = await _getNextNumAchats();
    _numAchatsController.text = nextNum;

    // Mode de paiement par défaut "A crédit"
    _selectedModePaiement = 'A crédit';

    // Dépôt par défaut = dernier utilisé
    final lastDepot = await _getLastUsedDepot();
    _selectedDepot = lastDepot;
    _depotController.text = lastDepot;

    _totalTTCController.text = '0';
    _totalFMGController.text = '0';

    // Focus automatique sur N° Facture/BL
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _nFactFocusNode.requestFocus();
      _ensureGlobalShortcutsFocus();
    });
  }

  // Méthode pour s'assurer que les raccourcis globaux restent actifs
  void _ensureGlobalShortcutsFocus() {
    if (!_globalShortcutsFocusNode.hasFocus) {
      final currentFocus = FocusScope.of(context).focusedChild;
      _globalShortcutsFocusNode.requestFocus();
      Future.delayed(const Duration(milliseconds: 50), () {
        currentFocus?.requestFocus();
      });
    }
  }

  Future<String> _getLastUsedDepot() async {
    try {
      final lastDetail =
          await (_databaseService.database.select(_databaseService.database.detachats)
                ..orderBy([(d) => OrderingTerm.desc(d.daty)])
                ..limit(1))
              .getSingleOrNull();
      return lastDetail?.depots ?? 'MAG';
    } catch (e) {
      return 'MAG';
    }
  }

  Future<void> _loadAchatsNumbers() async {
    try {
      final achats = await _databaseService.database.select(_databaseService.database.achats).get();

      setState(() {
        // Inclure tous les achats (y compris contre-passés)
        _achatsNumbers = achats
            .where((a) => (a.numachats ?? '').isNotEmpty)
            .map((a) => a.numachats!)
            .toList();
        _achatsNumbers.sort((a, b) => b.compareTo(a)); // Tri décroissant

        // Charger les statuts
        _achatsStatuts.clear();
        for (var achat in achats) {
          if (achat.numachats != null) {
            if (achat.contre == '1') {
              _achatsStatuts[achat.numachats!] = 'CONTRE-PASSé';
            } else {
              _achatsStatuts[achat.numachats!] = achat.verification ?? 'BROUILLARD';
            }
          }
        }
      });
    } catch (e) {
      setState(() {
        _achatsNumbers = [];
        _achatsStatuts.clear();
      });
    }
  }

  List<String> _getFilteredAchatsNumbers() {
    return _achatsNumbers.where((numAchat) {
      return _searchAchatsText.isEmpty || numAchat.toLowerCase().contains(_searchAchatsText);
    }).toList();
  }

  Future<String> _getNextNumAchats() async {
    try {
      // Récupérer tous les achats et trouver le plus grand numachats
      final achats = await _databaseService.database.select(_databaseService.database.achats).get();

      if (achats.isEmpty) {
        return '2607';
      }

      // Trouver le plus grand numéro d'achat
      int maxNum = 2606;
      for (var achat in achats) {
        if (achat.numachats != null) {
          final num = int.tryParse(achat.numachats!) ?? 0;
          if (num > maxNum) {
            maxNum = num;
          }
        }
      }

      return (maxNum + 1).toString();
    } catch (e) {
      // En cas d'erreur, commencer à  2607
      return '2607';
    }
  }

  Future<void> _loadData() async {
    try {
      final fournisseurs = await _databaseService.database.getActiveFournisseurs();
      final articles = await _databaseService.database.getActiveArticles();
      final depots = await _databaseService.database
          .select(_databaseService.database.depots)
          .map((d) => d.depots)
          .get();
      final modesPaiement = await _databaseService.database.select(_databaseService.database.mp).get();
      final societe = await (_databaseService.database.select(
        _databaseService.database.soc,
      )).getSingleOrNull();

      setState(() {
        _fournisseurs = fournisseurs;
        _articles = articles;
        _depots = depots.isNotEmpty ? depots.toSet().toList() : ['MAG'];
        _modesPaiement = modesPaiement;
        _societe = societe;
      });

      // Vérifier si "A crédit" existe
      if (!modesPaiement.any((mp) => mp.mp == 'A crédit')) {
        if (mounted) {
          _scaffoldMessengerKey.currentState?.showSnackBar(
            SnackBar(
              behavior: SnackBarBehavior.floating,
              margin: EdgeInsets.only(
                bottom: MediaQuery.of(context).size.height * 0.8,
                right: 20,
                left: MediaQuery.of(context).size.width * 0.75,
              ),
              content: const Text('Ajouter d\'abord un moyen de paiement'),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: Text('Erreur lors du chargement: $e'),
          ),
        );
      }
    }
  }

  Future<void> _verifierEtCreerFournisseur(String nomFournisseur) async {
    if (nomFournisseur.trim().isEmpty) return;

    // Vérifier si le fournisseur existe
    final fournisseurExiste = _fournisseurs.any(
      (frn) => frn.rsoc.toLowerCase() == nomFournisseur.toLowerCase(),
    );

    if (!fournisseurExiste) {
      // Afficher le modal de confirmation
      final confirmer =
          await showDialog<bool>(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('Fournisseur inconnu!!'),
              content: Text('Le fournisseur "$nomFournisseur" n\'existe pas.\n\nVoulez-vous le créer?'),
              actions: [
                TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Non')),
                TextButton(
                  autofocus: true,
                  onPressed: () => Navigator.of(context).pop(true),
                  child: const Text('Oui'),
                ),
              ],
            ),
          ) ??
          true;

      if (confirmer == true) {
        // Ouvrir le modal d'ajout de fournisseur avec le nom pré-rempli
        if (mounted) {
          await showDialog(
            context: context,
            builder: (context) => AddFournisseurModal(nomFournisseur: nomFournisseur),
          );
        }

        // Recharger la liste des fournisseurs
        await _loadData();

        // Chercher le fournisseur créé et le sélectionner
        final nouveauFournisseur = _fournisseurs
            .where((frn) => frn.rsoc.toLowerCase().contains(nomFournisseur.toLowerCase()))
            .firstOrNull;

        if (nouveauFournisseur != null) {
          setState(() {
            _selectedFournisseur = nouveauFournisseur.rsoc;
          });
        }
      } else {
        // Réinitialiser le champ fournisseur
        setState(() {
          _selectedFournisseur = null;
        });
      }
    }
  }

  void _onArticleSelected(Article? article) async {
    if (article == null) return;

    setState(() {
      _selectedArticle = article;
      // Unité u1 par défaut
      _selectedUnite = article.u1;
      // Dépôt de l'article par défaut depuis le champ dep
      _selectedDepot = article.dep ?? 'MAG';
      _depotController.text = article.dep ?? 'MAG';

      // Ne vider la quantité que si on n'est pas en mode modification
      if (!_isModifyingArticle) {
        _quantiteController.text = '';
      }
    });
  }

  Future<void> _verifierUniteArticle(String unite) async {
    if (_selectedArticle == null) return;

    // Vérifier si l'unité est valide pour cet article
    final unitesValides = [
      _selectedArticle!.u1,
      _selectedArticle!.u2,
      _selectedArticle!.u3,
    ].where((u) => u != null && u.isNotEmpty).toList();

    if (!unitesValides.contains(unite)) {
      // Désactiver temporairement le focus global pour éviter les conflits
      _globalShortcutsFocusNode.unfocus();

      // Afficher modal d'erreur avec focus garanti et isolation des shortcuts parents
      await showDialog(
        context: context,
        barrierDismissible: false,
        builder: (dialogContext) {
          // Créer un FocusNode pour le bouton
          final buttonFocusNode = FocusNode();

          return PopScope(
            canPop: true,
            onPopInvokedWithResult: (didPop, result) {
              // Nettoyer le FocusNode
              buttonFocusNode.dispose();
              // Restaurer le focus global après fermeture
              if (mounted) {
                _ensureGlobalShortcutsFocus();
              }
            },
            child: AlertDialog(
              title: const Text(
                'Unité invalide',
                style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red, fontSize: 18),
              ),
              content: Text(
                'L\'unité "$unite" n\'est pas valide pour l\'article "${_selectedArticle!.designation}".\n\nUnités autorisées: ${unitesValides.join(", ")}',
                style: const TextStyle(fontSize: 14),
              ),
              actions: [
                StatefulBuilder(
                  builder: (context, setState) {
                    // Demander le focus après la construction
                    WidgetsBinding.instance.addPostFrameCallback((_) {
                      buttonFocusNode.requestFocus();
                      setState(() {}); // Déclencher rebuild pour afficher la bordure
                    });

                    return Focus(
                      focusNode: buttonFocusNode,
                      onKeyEvent: (node, event) {
                        // Gérer les touches Enter et Escape directement
                        if (event is KeyDownEvent) {
                          if (event.logicalKey == LogicalKeyboardKey.enter ||
                              event.logicalKey == LogicalKeyboardKey.escape) {
                            Navigator.of(dialogContext).pop();
                            return KeyEventResult.handled;
                          }
                        }
                        return KeyEventResult.ignored;
                      },
                      child: ElevatedButton(
                        onPressed: () => Navigator.of(dialogContext).pop(),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blue,
                          foregroundColor: Colors.white,
                          padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                          elevation: 3,
                          side: buttonFocusNode.hasFocus
                              ? const BorderSide(color: Colors.blue, width: 3)
                              : null,
                        ),
                        child: const Text('OK', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                      ),
                    );
                  },
                ),
              ],
            ),
          );
        },
      );

      // Restaurer le focus global après fermeture
      _ensureGlobalShortcutsFocus();

      // Remettre l'unité par défaut et focus sur le champ unité
      setState(() {
        _uniteController.text = '';
      });

      // Focus sur le champ unité après fermeture du modal
      WidgetsBinding.instance.addPostFrameCallback((_) {
        _uniteFocusNode.requestFocus();
      });
      return;
    }

    _onUniteChanged(unite);
  }

  void _onUniteChanged(String? unite) {
    // Vérification des prérequis : article sélectionné et unité valide
    if (_selectedArticle == null || unite == null) return;

    setState(() {
      // Mise à  jour de l'unité sélectionnée
      _selectedUnite = unite;
      _uniteController.text = unite;

      // Calculer le prix selon CMUP avec conversion d'unité
      if ((_selectedArticle!.cmup ?? 0.0) == 0.0) {
        _prixController.text = '0';
      } else {
        // Convertir le CMUP selon l'unité sélectionnée
        // Le CMUP est stocké en unité de base (u3)
        double prixConverti = StockConverter.convertirPrixSelonUnite(
          article: _selectedArticle!,
          uniteSource: _selectedArticle!.u3 ?? 'Dét',
          uniteCible: unite,
          prixSource: _selectedArticle!.cmup!,
        );
        _prixController.text = NumberUtils.formatNumber(prixConverti);
      }

      // Réinitialisation de la quantité pour forcer une nouvelle saisie
      _quantiteController.text = '';
    });
  }

  List<DropdownMenuItem<String>> _getUnitsForSelectedArticle() {
    if (_selectedArticle == null) {
      return const [
        DropdownMenuItem(
          value: 'Pce',
          child: Text('Pce', style: TextStyle(fontSize: 12)),
        ),
      ];
    }

    List<DropdownMenuItem<String>> units = [];
    if (_selectedArticle!.u1?.isNotEmpty == true) {
      units.add(
        DropdownMenuItem(
          value: _selectedArticle!.u1,
          child: Text(_selectedArticle!.u1!, style: const TextStyle(fontSize: 12)),
        ),
      );
    }
    if (_selectedArticle!.u2?.isNotEmpty == true) {
      units.add(
        DropdownMenuItem(
          value: _selectedArticle!.u2,
          child: Text(_selectedArticle!.u2!, style: const TextStyle(fontSize: 12)),
        ),
      );
    }
    if (_selectedArticle!.u3?.isNotEmpty == true) {
      units.add(
        DropdownMenuItem(
          value: _selectedArticle!.u3,
          child: Text(_selectedArticle!.u3!, style: const TextStyle(fontSize: 12)),
        ),
      );
    }

    return units.isEmpty
        ? [
            const DropdownMenuItem(
              value: 'Pce',
              child: Text('Pce', style: TextStyle(fontSize: 12)),
            ),
          ]
        : units;
  }

  void _ajouterLigne() {
    if (_selectedArticle == null) return;

    double quantite = double.tryParse(_quantiteController.text) ?? 0.0;
    double prix = NumberUtils.parseFormattedNumber(_prixController.text);
    double montant = quantite * prix;

    String designation = _selectedArticle!.designation;
    String depot = _selectedDepot ?? 'MAG';
    String unite = _selectedUnite ?? 'Pce';

    debugPrint('Ajout ligne: $designation, Qté: $quantite, Prix: $prix, Unité: $unite, Dépôt: $depot');

    // Chercher si l'article existe déjÃ  avec la MÃŠME unité, le mÃªme dépôt ET le mÃªme prix
    int existingIndex = _lignesAchat.indexWhere(
      (ligne) =>
          ligne['designation'] == designation &&
          ligne['depot'] == depot &&
          ligne['unites'] == unite &&
          ligne['prixUnitaire'] == prix,
    );

    setState(() {
      if (existingIndex != -1) {
        // Cumuler les quantités si mÃªme article, mÃªme unité, mÃªme dépôt ET mÃªme prix
        double existingQuantite = _lignesAchat[existingIndex]['quantite'] ?? 0.0;
        double newQuantite = existingQuantite + quantite;
        double newMontant = newQuantite * prix;

        _lignesAchat[existingIndex]['quantite'] = newQuantite;
        _lignesAchat[existingIndex]['montant'] = newMontant;
      } else {
        // Ajouter nouvelle ligne si prix différent ou autres critères différents
        _lignesAchat.add({
          'designation': designation,
          'unites': unite,
          'quantite': quantite,
          'prixUnitaire': prix,
          'montant': montant,
          'depot': depot,
        });
      }
    });
    _calculerTotaux();
  }

  void _supprimerLigne(int index) {
    setState(() {
      _lignesAchat.removeAt(index);
    });
    _calculerTotaux();
  }

  void _calculerTotaux() {
    double totalHT = 0;
    for (var ligne in _lignesAchat) {
      totalHT += ligne['montant'] ?? 0;
    }

    double totalTTC = totalHT;
    double totalFMG = totalTTC * 5;

    setState(() {
      _totalTTCController.text = NumberUtils.formatNumber(totalTTC);
      _totalFMGController.text = NumberUtils.formatNumber(totalFMG);
    });
  }

  bool _isArticleFormValid() {
    return _selectedArticle != null &&
        _quantiteController.text.isNotEmpty &&
        int.tryParse(_quantiteController.text) != null &&
        int.tryParse(_quantiteController.text)! > 0;
  }

  void _validerAjout() async {
    debugPrint('Validation ajout - Mode modification: $_isModifyingArticle');
    if (_isModifyingArticle && _originalArticleData != null) {
      debugPrint('Suppression ancienne ligne: ${_originalArticleData!['designation']}');
      // En mode modification : supprimer l'ancienne ligne
      final originalIndex = _lignesAchat.indexWhere(
        (ligne) =>
            ligne['designation'] == _originalArticleData!['designation'] &&
            ligne['unites'] == _originalArticleData!['unites'] &&
            ligne['depot'] == _originalArticleData!['depot'],
      );

      if (originalIndex != -1) {
        _supprimerLigne(originalIndex);
      }
    }
    _ajouterLigne();
    await _resetArticleForm();
    debugPrint('Nombre total de lignes après ajout: ${_lignesAchat.length}');
  }

  Future<void> _resetArticleForm() async {
    final lastDepot = await _getLastUsedDepot();

    setState(() {
      _selectedArticle = null;
      _selectedUnite = null;
      _selectedDepot = lastDepot;
      _isModifyingArticle = false;
      _originalArticleData = null;
      _uniteController.clear();
      _depotController.text = lastDepot;
      _quantiteController.clear();
      _prixController.clear();
    });

    // Focus automatique sur Désignation Articles après ajout d'une ligne
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) {
        _articleFocusNode.requestFocus();
      }
    });
  }

  void _chargerLigneArticle(int index) {
    final ligne = _lignesAchat[index];

    // Trouver l'article correspondant
    Article? article = _articles.where((a) => a.designation == ligne['designation']).firstOrNull;

    setState(() {
      _selectedArticle = article;
      _selectedUnite = ligne['unites'];
      _selectedDepot = ligne['depot'];
      _isModifyingArticle = true;
      _originalArticleData = Map<String, dynamic>.from(ligne);

      _uniteController.text = ligne['unites'];
      _depotController.text = ligne['depot'];
      _quantiteController.text = ligne['quantite'].toString();
      _prixController.text = NumberUtils.formatNumber(ligne['prixUnitaire']?.toDouble() ?? 0);
    });

    // Focus sur le champ désignation après chargement
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _articleFocusNode.requestFocus();
    });
  }

  Future<void> _chargerAchatExistant(String numAchats) async {
    debugPrint('=== CHARGEMENT ACHAT EXISTANT ===');
    debugPrint('Numéro achat à  charger: $numAchats');

    if (numAchats.isEmpty) {
      debugPrint('Numéro achat vide, réinitialisation');
      setState(() {
        _isExistingPurchase = false;
      });
      return;
    }

    try {
      // Rechercher l'achat principal
      final achat = await (_databaseService.database.select(
        _databaseService.database.achats,
      )..where((a) => a.numachats.equals(numAchats))).getSingleOrNull();

      setState(() {
        _isExistingPurchase = achat != null;
        // IMPORTANT: Mettre à  jour le numéro d'achat AVANT tout autre traitement
        _numAchatsController.text = numAchats;
      });

      debugPrint('Achat trouvé: ${achat != null}');
      if (achat != null) {
        debugPrint('Statut achat: ${achat.verification}');
        debugPrint('Contre-passé: ${achat.contre}');
      }

      if (achat != null) {
        // Charger les détails de l'achat
        final details = await (_databaseService.database.select(
          _databaseService.database.detachats,
        )..where((d) => d.numachats.equals(numAchats))).get();

        setState(() {
          // Remplir les champs principaux
          _nFactController.text = achat.nfact ?? '';
          if (achat.daty != null) {
            _dateController.text = app_date.AppDateUtils.formatDate(achat.daty!);
          }
          _selectedFournisseur = achat.frns;
          _fournisseurController.text = achat.frns ?? ''; // Mettre à  jour le contrôleur
          _selectedModePaiement = achat.modepai;
          if (achat.echeance != null) {
            _echeanceController.text = app_date.AppDateUtils.formatDate(achat.echeance!);

            // Calculer les jours d'échéance
            if (achat.daty != null) {
              final joursEcheance = achat.echeance!.difference(achat.daty!).inDays;
              _echeanceJoursController.text = joursEcheance.toString();
            }
          } else {
            // Valeurs par défaut si pas d'échéance
            _echeanceJoursController.text = '7';
            if (achat.daty != null) {
              final echeanceDefaut = achat.daty!.add(const Duration(days: 7));
              _echeanceController.text = app_date.AppDateUtils.formatDate(echeanceDefaut);
            }
          }
          _statutAchatActuel = achat.verification ?? 'BROUILLARD';
          _selectedStatut = _statutAchatActuel == 'JOURNAL' ? 'Journal' : 'Brouillard';
          debugPrint('Statut achat actuel: $_statutAchatActuel');
          debugPrint('Statut sélectionné: $_selectedStatut');

          // Vérifier si l'achat est contre-passé
          final isContrePasse = achat.contre == '1';
          if (isContrePasse) {
            _statutAchatActuel = 'CONTRE-PASSé';
          }

          // Remplir les lignes d'achat
          _lignesAchat.clear();
          debugPrint('Chargement de ${details.length} lignes de détail');
          for (var detail in details) {
            _lignesAchat.add({
              'designation': detail.designation ?? '',
              'unites': detail.unites ?? '',
              'quantite': detail.q ?? 0.0,
              'prixUnitaire': detail.pu ?? 0.0,
              'montant': (detail.q ?? 0.0) * (detail.pu ?? 0.0),
              'depot': detail.depots ?? '',
            });
          }
        });

        _calculerTotaux();
        debugPrint('Totaux recalculés');

        // Mettre à  jour l'index de navigation
        currentAchatIndex = _achatsNumbers.indexOf(numAchats);
        debugPrint('Index de navigation: $currentAchatIndex');

        // Donner le focus au champ Désignation Articles après le chargement
        WidgetsBinding.instance.addPostFrameCallback((_) {
          _articleFocusNode.requestFocus();
        });
      } else {
        debugPrint('Achat non trouvé dans la base de données');
        if (mounted) {
          _scaffoldMessengerKey.currentState?.showSnackBar(
            SnackBar(
              behavior: SnackBarBehavior.floating,
              margin: EdgeInsets.only(
                bottom: MediaQuery.of(context).size.height * 0.8,
                right: 20,
                left: MediaQuery.of(context).size.width * 0.75,
              ),
              content: Text('Achat N° $numAchats non trouvé'),
            ),
          );
        }
      }
      debugPrint('=== FIN CHARGEMENT ACHAT EXISTANT ===');
    } catch (e) {
      debugPrint('ERREUR lors du chargement: $e');
      setState(() {
        _isExistingPurchase = false;
      });
      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: Text('Erreur lors du chargement: $e'),
          ),
        );
      }
    }
  }

  Future<void> _modifierAchat() async {
    debugPrint('=== DéBUT MODIFICATION ACHAT ===');
    debugPrint('Numéro achat: ${_numAchatsController.text}');
    debugPrint('Fournisseur sélectionné: $_selectedFournisseur');
    debugPrint('N° Facture: ${_nFactController.text}');
    debugPrint('Nombre de lignes: ${_lignesAchat.length}');
    debugPrint('Mode achat existant: $_isExistingPurchase');
    debugPrint('Statut sélectionné: $_selectedStatut');
    debugPrint('Statut achat actuel: $_statutAchatActuel');

    if (_selectedFournisseur == null || _nFactController.text.isEmpty || _lignesAchat.isEmpty) {
      debugPrint('ERREUR: Données manquantes pour la modification');
      _scaffoldMessengerKey.currentState?.showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          margin: EdgeInsets.only(
            bottom: MediaQuery.of(context).size.height * 0.8,
            right: 20,
            left: MediaQuery.of(context).size.width * 0.75,
          ),
          content: const Text(
            'Veuillez sélectionner un fournisseur, saisir le N° Facture/BL et ajouter des articles',
          ),
        ),
      );
      return;
    }

    // Vérifier que nous sommes bien en mode modification d'un achat existant
    if (!_isExistingPurchase || _numAchatsController.text.isEmpty) {
      debugPrint('ERREUR: Pas en mode modification ou numéro achat vide');
      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: const Text('Aucun achat sélectionné pour modification'),
          ),
        );
      }
      return;
    }

    // Désactiver temporairement le focus global pour éviter les conflits
    _globalShortcutsFocusNode.unfocus();

    // Confirmation avant modification
    final confirm = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) {
        // Créer des FocusNodes pour les boutons
        final annulerButtonFocusNode = FocusNode();
        final confirmerButtonFocusNode = FocusNode();

        return PopScope(
          canPop: true,
          onPopInvokedWithResult: (didPop, result) {
            // Nettoyer les FocusNodes
            annulerButtonFocusNode.dispose();
            confirmerButtonFocusNode.dispose();
            // Restaurer le focus global après fermeture
            if (mounted) {
              _ensureGlobalShortcutsFocus();
            }
          },
          child: AlertDialog(
            title: const Text(
              'Confirmation modification achat',
              style: TextStyle(fontWeight: FontWeight.bold, color: Colors.orange, fontSize: 18),
            ),
            content: Text(
              'Voulez-vous vraiment modifier l\'achat N° ${_numAchatsController.text} ?\n\nCette action mettra à  jour les stocks et les CMUP.',
              style: const TextStyle(fontSize: 14),
            ),
            actions: [
              StatefulBuilder(
                builder: (context, setState) {
                  // Demander le focus après la construction
                  WidgetsBinding.instance.addPostFrameCallback((_) {
                    annulerButtonFocusNode.requestFocus();
                    setState(() {}); // Déclencher rebuild pour afficher la bordure
                  });

                  return Focus(
                    focusNode: annulerButtonFocusNode,
                    onKeyEvent: (node, event) {
                      // Gérer les touches Enter et Escape directement
                      if (event is KeyDownEvent) {
                        if (event.logicalKey == LogicalKeyboardKey.enter ||
                            event.logicalKey == LogicalKeyboardKey.escape) {
                          Navigator.of(dialogContext).pop(false);
                          return KeyEventResult.handled;
                        }
                        if (event.logicalKey == LogicalKeyboardKey.tab) {
                          confirmerButtonFocusNode.requestFocus();
                          return KeyEventResult.handled;
                        }
                      }
                      return KeyEventResult.ignored;
                    },
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(dialogContext).pop(false),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.grey,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                        elevation: 3,
                        side: annulerButtonFocusNode.hasFocus
                            ? const BorderSide(color: Colors.grey, width: 3)
                            : null,
                      ),
                      child: const Text(
                        'Annuler',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  );
                },
              ),
              const SizedBox(width: 8),
              StatefulBuilder(
                builder: (context, setState) {
                  return Focus(
                    focusNode: confirmerButtonFocusNode,
                    onKeyEvent: (node, event) {
                      // Gérer les touches Enter et Escape directement
                      if (event is KeyDownEvent) {
                        if (event.logicalKey == LogicalKeyboardKey.enter) {
                          Navigator.of(dialogContext).pop(true);
                          return KeyEventResult.handled;
                        }
                        if (event.logicalKey == LogicalKeyboardKey.escape) {
                          Navigator.of(dialogContext).pop(false);
                          return KeyEventResult.handled;
                        }
                        if (event.logicalKey == LogicalKeyboardKey.tab) {
                          annulerButtonFocusNode.requestFocus();
                          return KeyEventResult.handled;
                        }
                      }
                      return KeyEventResult.ignored;
                    },
                    child: ElevatedButton(
                      onPressed: () => Navigator.of(dialogContext).pop(true),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.orange,
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                        elevation: 3,
                        side: confirmerButtonFocusNode.hasFocus
                            ? const BorderSide(color: Colors.orange, width: 3)
                            : null,
                      ),
                      child: const Text(
                        'Confirmer',
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  );
                },
              ),
            ],
          ),
        );
      },
    );

    // Restaurer le focus global après fermeture
    _ensureGlobalShortcutsFocus();

    if (confirm != true) return;

    try {
      debugPrint('Début de la transaction de modification');
      await _databaseService.database.transaction(() async {
        List<String> dateParts = _dateController.text.split('-');
        DateTime dateForDB = DateTime(
          int.parse(dateParts[2]),
          int.parse(dateParts[1]),
          int.parse(dateParts[0]),
        );

        // Récupérer les anciennes lignes pour annuler leur impact sur les stocks
        final anciennesLignes = await (_databaseService.database.select(
          _databaseService.database.detachats,
        )..where((d) => d.numachats.equals(_numAchatsController.text))).get();
        debugPrint('Anciennes lignes trouvées: ${anciennesLignes.length}');

        // Recharger les articles pour avoir les stocks actuels
        _articles = await _databaseService.database.getActiveArticles();

        // Annuler l'impact des anciennes lignes avec conversion automatique
        for (var ancienneLigne in anciennesLignes) {
          Article? article = _articles.firstWhere(
            (a) => a.designation == ancienneLigne.designation,
            orElse: () => throw Exception('Article ${ancienneLigne.designation} non trouvé'),
          );

          // Convertir l'ancienne quantité en unités optimales pour annulation
          final conversionAnnulation = StockConverter.convertirQuantiteAchat(
            article: article,
            uniteAchat: ancienneLigne.unites ?? article.u3!,
            quantiteAchat: ancienneLigne.q ?? 0,
          );

          // Annuler les stocks articles avec conversion automatique
          final stocksActuelsArticle = StockConverter.convertirStockOptimal(
            article: article,
            quantiteU1: (article.stocksu1 ?? 0) - conversionAnnulation['u1']!,
            quantiteU2: (article.stocksu2 ?? 0) - conversionAnnulation['u2']!,
            quantiteU3: (article.stocksu3 ?? 0) - conversionAnnulation['u3']!,
          );

          await (_databaseService.database.update(
            _databaseService.database.articles,
          )..where((a) => a.designation.equals(article.designation))).write(
            ArticlesCompanion(
              stocksu1: Value(stocksActuelsArticle['u1']! >= 0 ? stocksActuelsArticle['u1']! : 0),
              stocksu2: Value(stocksActuelsArticle['u2']! >= 0 ? stocksActuelsArticle['u2']! : 0),
              stocksu3: Value(stocksActuelsArticle['u3']! >= 0 ? stocksActuelsArticle['u3']! : 0),
            ),
          );

          // Annuler les stocks par dépôt avec conversion automatique
          final existingDepart =
              await (_databaseService.database.select(_databaseService.database.depart)..where(
                    (d) =>
                        d.designation.equals(article.designation) &
                        d.depots.equals(ancienneLigne.depots ?? ''),
                  ))
                  .getSingleOrNull();

          if (existingDepart != null) {
            final stocksActuelsDepot = StockConverter.convertirStockOptimal(
              article: article,
              quantiteU1: (existingDepart.stocksu1 ?? 0) - conversionAnnulation['u1']!,
              quantiteU2: (existingDepart.stocksu2 ?? 0) - conversionAnnulation['u2']!,
              quantiteU3: (existingDepart.stocksu3 ?? 0) - conversionAnnulation['u3']!,
            );

            await (_databaseService.database.update(_databaseService.database.depart)..where(
                  (d) =>
                      d.designation.equals(article.designation) & d.depots.equals(ancienneLigne.depots ?? ''),
                ))
                .write(
                  DepartCompanion(
                    stocksu1: Value(stocksActuelsDepot['u1']! >= 0 ? stocksActuelsDepot['u1']! : 0),
                    stocksu2: Value(stocksActuelsDepot['u2']! >= 0 ? stocksActuelsDepot['u2']! : 0),
                    stocksu3: Value(stocksActuelsDepot['u3']! >= 0 ? stocksActuelsDepot['u3']! : 0),
                  ),
                );
          }

          // Recalculer le CMUP après annulation
          await _recalculerCMUPApresAnnulation(article, ancienneLigne.q ?? 0, ancienneLigne.pu ?? 0);
        }

        // Supprimer les anciennes entrées de stock
        await (_databaseService.database.delete(
          _databaseService.database.stocks,
        )..where((s) => s.numachats.equals(_numAchatsController.text))).go();

        // Supprimer les anciennes lignes
        await (_databaseService.database.delete(
          _databaseService.database.detachats,
        )..where((d) => d.numachats.equals(_numAchatsController.text))).go();

        // Calculer la date d'échéance
        DateTime? dateEcheance;
        if (_echeanceController.text.isNotEmpty) {
          List<String> echeanceParts = _echeanceController.text.split('-');
          dateEcheance = DateTime(
            int.parse(echeanceParts[2]),
            int.parse(echeanceParts[1]),
            int.parse(echeanceParts[0]),
          );
        }

        // Mettre à  jour l'achat principal (GARDER LE MÃŠME NUMéRO)
        debugPrint(
          'Mise à  jour achat principal avec statut: ${_selectedStatut == 'Journal' ? 'JOURNAL' : 'BROUILLARD'}',
        );
        await (_databaseService.database.update(
          _databaseService.database.achats,
        )..where((a) => a.numachats.equals(_numAchatsController.text))).write(
          AchatsCompanion(
            nfact: Value(_nFactController.text.isEmpty ? null : _nFactController.text),
            daty: Value(dateForDB),
            frns: Value(_selectedFournisseur!),
            modepai: Value(_selectedModePaiement),
            echeance: Value(dateEcheance),
            totalttc: Value(double.tryParse(_totalTTCController.text.replaceAll(' ', '')) ?? 0.0),
            verification: Value(_selectedStatut == 'Journal' ? 'JOURNAL' : 'BROUILLARD'),
          ),
        );

        // Recharger les articles pour avoir les stocks mis à  jour après annulation
        _articles = await _databaseService.database.getActiveArticles();

        // Insérer les nouvelles lignes avec le MÃŠME numéro d'achat
        debugPrint('Insertion de ${_lignesAchat.length} nouvelles lignes');
        for (var ligne in _lignesAchat) {
          await _databaseService.database
              .into(_databaseService.database.detachats)
              .insert(
                DetachatsCompanion.insert(
                  numachats: Value(_numAchatsController.text), // MÃŠME NUMéRO
                  designation: Value(ligne['designation']),
                  unites: Value(ligne['unites']),
                  depots: Value(ligne['depot']),
                  q: Value(ligne['quantite']),
                  pu: Value(ligne['prixUnitaire']),
                  daty: Value(dateForDB),
                ),
              );

          // Mettre à  jour le stock et le CMUP dans la table Articles
          Article? article = _articles.firstWhere(
            (a) => a.designation == ligne['designation'],
            orElse: () => throw Exception('Article ${ligne['designation']} non trouvé'),
          );

          // Calculer et mettre à  jour le CMUP avec le calculateur amélioré
          double nouveauCMUP = await CMUPCalculator.calculerEtMettreAJourCMUP(
            designation: ligne['designation'],
            uniteAchat: ligne['unites'],
            quantiteAchat: ligne['quantite'],
            prixUnitaireAchat: ligne['prixUnitaire'],
            article: article,
          );

          // Créer nouvelle entrée de stock avec le MÃŠME numéro d'achat
          // Générer une référence unique avec un délai pour éviter les doublons
          await Future.delayed(const Duration(milliseconds: 1));
          final cleanDesignation = ligne['designation'].replaceAll(' ', '');
          final maxLength = cleanDesignation.length > 10 ? 10 : cleanDesignation.length;
          final stockRef =
              'ACH-${_numAchatsController.text}-${cleanDesignation.substring(0, maxLength)}-${DateTime.now().millisecondsSinceEpoch}-${_lignesAchat.indexOf(ligne)}';
          await _databaseService.database
              .into(_databaseService.database.stocks)
              .insert(
                StocksCompanion.insert(
                  ref: stockRef,
                  daty: Value(dateForDB),
                  lib: Value('Achat ${_numAchatsController.text} (Modifié)'),
                  numachats: Value(_numAchatsController.text), // MÃŠME NUMéRO
                  nfact: Value(_nFactController.text.isEmpty ? null : _nFactController.text),
                  refart: Value(ligne['designation']),
                  qe: Value(ligne['quantite']),
                  entres: Value(ligne['quantite']),
                  ue: Value(ligne['unites']),
                  depots: Value(ligne['depot']),
                  pue: Value(ligne['prixUnitaire']),
                  pus: Value(ligne['prixUnitaire']),
                  cmup: Value(nouveauCMUP),
                  frns: Value(_selectedFournisseur!),
                  verification: Value(_selectedStatut == 'Journal' ? 'JOURNAL' : 'BROUILLARD'),
                ),
              );

          // Convertir l'achat en unités optimales
          final conversionAchat = StockConverter.convertirQuantiteAchat(
            article: article,
            uniteAchat: ligne['unites'],
            quantiteAchat: ligne['quantite'],
          );

          // Calculer les nouveaux stocks avec conversion automatique
          final stocksActuels = StockConverter.convertirStockOptimal(
            article: article,
            quantiteU1: (article.stocksu1 ?? 0) + conversionAchat['u1']!,
            quantiteU2: (article.stocksu2 ?? 0) + conversionAchat['u2']!,
            quantiteU3: (article.stocksu3 ?? 0) + conversionAchat['u3']!,
          );

          // Mettre à  jour les stocks avec conversion automatique
          await (_databaseService.database.update(
            _databaseService.database.articles,
          )..where((a) => a.designation.equals(article.designation))).write(
            ArticlesCompanion(
              stocksu1: Value(stocksActuels['u1']!),
              stocksu2: Value(stocksActuels['u2']!),
              stocksu3: Value(stocksActuels['u3']!),
            ),
          );

          // Mettre à  jour les stocks par dépôt avec conversion automatique
          final existingDepart =
              await (_databaseService.database.select(_databaseService.database.depart)..where(
                    (d) => d.designation.equals(article.designation) & d.depots.equals(ligne['depot']),
                  ))
                  .getSingleOrNull();

          if (existingDepart != null) {
            // Calculer les nouveaux stocks du dépôt avec conversion automatique
            final stocksDepotActuels = StockConverter.convertirStockOptimal(
              article: article,
              quantiteU1: (existingDepart.stocksu1 ?? 0) + conversionAchat['u1']!,
              quantiteU2: (existingDepart.stocksu2 ?? 0) + conversionAchat['u2']!,
              quantiteU3: (existingDepart.stocksu3 ?? 0) + conversionAchat['u3']!,
            );

            await (_databaseService.database.update(_databaseService.database.depart)
                  ..where((d) => d.designation.equals(article.designation) & d.depots.equals(ligne['depot'])))
                .write(
                  DepartCompanion(
                    stocksu1: Value(stocksDepotActuels['u1']!),
                    stocksu2: Value(stocksDepotActuels['u2']!),
                    stocksu3: Value(stocksDepotActuels['u3']!),
                  ),
                );
          } else {
            // Créer nouvelle entrée avec conversion automatique
            final stocksDepotInitiaux = StockConverter.convertirStockOptimal(
              article: article,
              quantiteU1: conversionAchat['u1']!,
              quantiteU2: conversionAchat['u2']!,
              quantiteU3: conversionAchat['u3']!,
            );

            await _databaseService.database
                .into(_databaseService.database.depart)
                .insert(
                  DepartCompanion.insert(
                    designation: article.designation,
                    depots: ligne['depot'],
                    stocksu1: Value(stocksDepotInitiaux['u1']!),
                    stocksu2: Value(stocksDepotInitiaux['u2']!),
                    stocksu3: Value(stocksDepotInitiaux['u3']!),
                  ),
                );
          }
        }
      });

      debugPrint('Transaction de modification terminée avec succès');

      // Recharger la liste des achats
      await _loadAchatsNumbers();
      debugPrint('Liste des achats rechargée');

      // Recharger les données pour mettre à  jour l'interface
      await _loadData();

      // Recalculer les totaux avec les nouvelles données
      _calculerTotaux();

      // IMPORTANT: Synchroniser le statut après modification
      final statutFinal = _selectedStatut == 'Journal' ? 'JOURNAL' : 'BROUILLARD';
      setState(() {
        _statutAchatActuel = statutFinal;
        _achatsStatuts[_numAchatsController.text] = statutFinal;
      });
      debugPrint('Statut synchronisé après modification: $statutFinal');

      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: const Text('Achat modifié avec succès'),
          ),
        );
      }
      debugPrint('=== FIN MODIFICATION ACHAT RéUSSIE ===');
      debugPrint('Statut final après modification: $_statutAchatActuel');
    } catch (e) {
      debugPrint('ERREUR lors de la modification: $e');
      debugPrint('Stack trace: ${StackTrace.current}');
      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: Text('Erreur lors de la modification: $e'),
          ),
        );
      }
    }
  }

  Future<void> _contrePasserAchat() async {
    if (!_isExistingPurchase) {
      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          const SnackBar(content: Text('Aucun achat sélectionné à  contre-passer')),
        );
      }
      return;
    }

    // Vérifier si l'achat est déjÃ  contre-passé
    final achatActuel = await (_databaseService.database.select(
      _databaseService.database.achats,
    )..where((a) => a.numachats.equals(_numAchatsController.text))).getSingleOrNull();

    if (achatActuel?.contre == '1') {
      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: const Text('Cet achat est déjÃ  contre-passé'),
          ),
        );
      }
      return;
    }

    // Vérifier si l'achat est journalisé
    final isJournalise = achatActuel?.verification == 'JOURNAL';

    // Confirmation avec message adapté
    if (!mounted) return;
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirmation'),
        content: Text(
          'Voulez-vous vraiment contre-passer l\'achat N° ${_numAchatsController.text} ?\n\n${isJournalise ? "Cet achat journalisé sera marqué comme contre-passé et exclu des listes." : "Cet achat brouillard sera SUPPRIMé DéFINITIVEMENT."}',
        ),
        actions: [
          TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Annuler')),
          TextButton(
            onPressed: () => Navigator.of(context).pop(true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Confirmer'),
          ),
        ],
      ),
    );
    if (confirm != true) return;

    try {
      // Utiliser le service pour contre-passer l'achat
      if (isJournalise) {
        await _achatService.contrePasserAchatJournal(_numAchatsController.text);
      } else {
        await _achatService.contrePasserAchatBrouillard(_numAchatsController.text);
      }

      // Recharger toutes les données pour mettre à  jour l'interface
      await _loadAchatsNumbers();
      await _loadData();

      // Mettre à  jour l'interface pour refléter le statut contre-passé
      // Créer un nouvel achat après contre-passement
      if (mounted) {
        await _creerNouvelAchat();
      }

      if (mounted) {
        final message = isJournalise ? 'Achat contre-passé avec succès' : 'Achat supprimé définitivement';
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: Text(message),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(content: Text('Erreur lors du contre-passement: $e')),
        );
      }
    }
  }

  Future<void> _validerAchatBrouillard() async {
    debugPrint('=== DéBUT VALIDATION ACHAT BROUILLARD ===');
    debugPrint('Achat existant: $_isExistingPurchase');
    debugPrint('Statut achat actuel: $_statutAchatActuel');
    debugPrint('Numéro achat: ${_numAchatsController.text}');

    // Vérifier le statut réel dans la base de données
    final achatActuel = await (_databaseService.database.select(
      _databaseService.database.achats,
    )..where((a) => a.numachats.equals(_numAchatsController.text))).getSingleOrNull();

    final statutReel = achatActuel?.verification ?? 'BROUILLARD';
    debugPrint('Statut réel en base: $statutReel');

    // Synchroniser le statut si nécessaire
    if (_statutAchatActuel != statutReel) {
      debugPrint('Synchronisation du statut: $_statutAchatActuel -> $statutReel');
      setState(() {
        _statutAchatActuel = statutReel;
        _selectedStatut = statutReel == 'JOURNAL' ? 'Journal' : 'Brouillard';
      });
    }

    if (!_isExistingPurchase || _statutAchatActuel != 'BROUILLARD') {
      debugPrint('ERREUR: Conditions non remplies pour validation brouillard');
      debugPrint('isExistingPurchase: $_isExistingPurchase, statutActuel: $_statutAchatActuel');
      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: const Text('Aucun achat en brouillard sélectionné'),
          ),
        );
      }
      return;
    }

    // Désactiver temporairement le focus global pour éviter les conflits
    _globalShortcutsFocusNode.unfocus();

    final confirm = mounted
        ? await showDialog<bool>(
            context: context,
            barrierDismissible: false,
            builder: (dialogContext) {
              // Créer des FocusNodes pour les boutons
              final annulerButtonFocusNode = FocusNode();
              final enregistrerButtonFocusNode = FocusNode();

              return PopScope(
                canPop: true,
                onPopInvokedWithResult: (didPop, result) {
                  // Nettoyer les FocusNodes
                  annulerButtonFocusNode.dispose();
                  enregistrerButtonFocusNode.dispose();
                  // Restaurer le focus global après fermeture
                  if (mounted) {
                    _ensureGlobalShortcutsFocus();
                  }
                },
                child: AlertDialog(
                  title: const Text(
                    'Confirmation validation brouillard',
                    style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green, fontSize: 18),
                  ),
                  content: Text(
                    'Enregistrer l\'achat N° ${_numAchatsController.text} vers le journal ?\n\nCette action créera les mouvements de stock.',
                    style: const TextStyle(fontSize: 14),
                  ),
                  actions: [
                    StatefulBuilder(
                      builder: (context, setState) {
                        return Focus(
                          focusNode: annulerButtonFocusNode,
                          onKeyEvent: (node, event) {
                            // Gérer les touches Enter et Escape directement
                            if (event is KeyDownEvent) {
                              if (event.logicalKey == LogicalKeyboardKey.escape) {
                                Navigator.of(dialogContext).pop(false);
                                return KeyEventResult.handled;
                              }
                              if (event.logicalKey == LogicalKeyboardKey.tab) {
                                enregistrerButtonFocusNode.requestFocus();
                                return KeyEventResult.handled;
                              }
                            }
                            return KeyEventResult.ignored;
                          },
                          child: ElevatedButton(
                            onPressed: () => Navigator.of(dialogContext).pop(false),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.grey,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                              elevation: 3,
                              side: annulerButtonFocusNode.hasFocus
                                  ? const BorderSide(color: Colors.grey, width: 3)
                                  : null,
                            ),
                            child: const Text(
                              'Annuler',
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                          ),
                        );
                      },
                    ),
                    const SizedBox(width: 8),
                    StatefulBuilder(
                      builder: (context, setState) {
                        // Demander le focus après la construction
                        WidgetsBinding.instance.addPostFrameCallback((_) {
                          enregistrerButtonFocusNode.requestFocus();
                          setState(() {}); // Déclencher rebuild pour afficher la bordure
                        });

                        return Focus(
                          focusNode: enregistrerButtonFocusNode,
                          onKeyEvent: (node, event) {
                            // Gérer les touches Enter et Escape directement
                            if (event is KeyDownEvent) {
                              if (event.logicalKey == LogicalKeyboardKey.enter) {
                                Navigator.of(dialogContext).pop(true);
                                return KeyEventResult.handled;
                              }
                              if (event.logicalKey == LogicalKeyboardKey.escape) {
                                Navigator.of(dialogContext).pop(false);
                                return KeyEventResult.handled;
                              }
                              if (event.logicalKey == LogicalKeyboardKey.tab) {
                                annulerButtonFocusNode.requestFocus();
                                return KeyEventResult.handled;
                              }
                            }
                            return KeyEventResult.ignored;
                          },
                          child: ElevatedButton(
                            onPressed: () => Navigator.of(dialogContext).pop(true),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              foregroundColor: Colors.white,
                              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 12),
                              elevation: 3,
                              side: enregistrerButtonFocusNode.hasFocus
                                  ? const BorderSide(color: Colors.green, width: 3)
                                  : null,
                            ),
                            child: const Text(
                              'Enregistrer',
                              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                            ),
                          ),
                        );
                      },
                    ),
                  ],
                ),
              );
            },
          )
        : null;

    // Restaurer le focus global après fermeture
    _ensureGlobalShortcutsFocus();

    if (confirm != true) return;

    try {
      debugPrint('Appel du service de validation brouillard');
      await _achatService.validerAchatBrouillard(_numAchatsController.text);
      debugPrint('Service de validation brouillard terminé avec succès');

      setState(() {
        _statutAchatActuel = 'JOURNAL';
        _achatsStatuts[_numAchatsController.text] = 'JOURNAL';
      });
      debugPrint('état mis à  jour: statut = JOURNAL');

      await _loadData();
      debugPrint('Données rechargées');

      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: const Text('Achat validé avec succès'),
            backgroundColor: Colors.green,
          ),
        );
      }
      debugPrint('=== FIN VALIDATION ACHAT BROUILLARD RéUSSIE ===');
    } catch (e) {
      debugPrint('ERREUR lors de la validation brouillard: $e');
      debugPrint('Stack trace: ${StackTrace.current}');
      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: SelectableText('Erreur lors de la validation: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> _recalculerCMUPApresAnnulation(
    Article article,
    double quantiteAnnulee,
    double prixAnnule,
  ) async {
    // Calculer le stock total en unité de base (u3) avec conversion automatique
    double stockActuelU3 = StockConverter.calculerStockTotalU3(
      article: article,
      stockU1: article.stocksu1 ?? 0,
      stockU2: article.stocksu2 ?? 0,
      stockU3: article.stocksu3 ?? 0,
    );

    double cmupActuel = article.cmup ?? 0.0;

    // Convertir la quantité annulée en u3 pour le calcul
    double quantiteAnnuleeU3 = quantiteAnnulee;
    if (article.tu3u2 != null && article.tu2u1 != null) {
      // Supposer que le prix est en u3, ajuster si nécessaire
      quantiteAnnuleeU3 = quantiteAnnulee;
    }

    double valeurTotaleAvant = (stockActuelU3 + quantiteAnnuleeU3) * cmupActuel;
    double valeurARetirer = quantiteAnnuleeU3 * prixAnnule;
    double nouvelleValeur = valeurTotaleAvant - valeurARetirer;
    double nouveauCMUP = stockActuelU3 > 0 ? nouvelleValeur / stockActuelU3 : 0.0;

    // S'assurer que le CMUP ne devient pas négatif
    nouveauCMUP = nouveauCMUP >= 0 ? nouveauCMUP : 0.0;

    await (_databaseService.database.update(_databaseService.database.articles)
          ..where((a) => a.designation.equals(article.designation)))
        .write(ArticlesCompanion(cmup: Value(nouveauCMUP)));
  }

  Future<String> _getStocksToutesUnites(Article article, String depot) async {
    try {
      final stockDepart = await (_databaseService.database.select(
        _databaseService.database.depart,
      )..where((d) => d.designation.equals(article.designation) & d.depots.equals(depot))).getSingleOrNull();

      double stockTotalU3 = StockConverter.calculerStockTotalU3(
        article: article,
        stockU1: stockDepart?.stocksu1 ?? 0.0,
        stockU2: stockDepart?.stocksu2 ?? 0.0,
        stockU3: stockDepart?.stocksu3 ?? 0.0,
      );

      final stocksOptimaux = StockConverter.convertirStockOptimal(
        article: article,
        quantiteU1: 0.0,
        quantiteU2: 0.0,
        quantiteU3: stockTotalU3,
      );

      return StockConverter.formaterAffichageStock(
        article: article,
        stockU1: stocksOptimaux['u1']!,
        stockU2: stocksOptimaux['u2']!,
        stockU3: stocksOptimaux['u3']!,
      );
    } catch (e) {
      return '';
    }
  }

  void _naviguerAchat(bool suivant) {
    final filteredNumbers = _getFilteredAchatsNumbers();
    if (filteredNumbers.isEmpty) return;

    int currentIndex = filteredNumbers.indexOf(_numAchatsController.text);
    if (currentIndex == -1) currentIndex = 0;

    if (suivant) {
      currentIndex = (currentIndex + 1) % filteredNumbers.length;
    } else {
      currentIndex = (currentIndex - 1 + filteredNumbers.length) % filteredNumbers.length;
    }

    final numAchat = filteredNumbers[currentIndex];
    _numAchatsController.text = numAchat;
    currentAchatIndex = _achatsNumbers.indexOf(numAchat);
    _chargerAchatExistant(numAchat);
  }

  Future<void> _ouvrirApercuBR() async {
    if (_lignesAchat.isEmpty) {
      _scaffoldMessengerKey.currentState?.showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          margin: EdgeInsets.only(
            bottom: MediaQuery.of(context).size.height * 0.8,
            right: 20,
            left: MediaQuery.of(context).size.width * 0.75,
          ),
          content: const Text('Aucun article à  afficher'),
        ),
      );
      return;
    }

    DateTime dateForPreview = app_date.AppDateUtils.parseDate(_dateController.text);

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => BonReceptionPreview(
          numAchats: _numAchatsController.text,
          nFact: _nFactController.text.isEmpty ? null : _nFactController.text,
          date: dateForPreview,
          fournisseur: _selectedFournisseur ?? '',
          modePaiement: _selectedModePaiement,
          lignesAchat: _lignesAchat,
          totalTTC: double.tryParse(_totalTTCController.text.replaceAll(' ', '')) ?? 0.0,
          format: _selectedFormat,
          societe: _societe,
        ),
      ),
    );
  }

  Future<void> _importerLignesAchat() async {
    final choix = await showDialog<String>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Importer lignes d\'achat'),
        content: const Text('Choisissez la source d\'importation :'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop('base_actuelle'),
            child: const Text('Base actuelle'),
          ),
          TextButton(
            onPressed: () => Navigator.of(context).pop('base_externe'),
            child: const Text('Base externe'),
          ),
          TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Annuler')),
        ],
      ),
    );

    if (choix == 'base_actuelle') {
      await _importerDepuisBaseActuelle();
    } else if (choix == 'base_externe') {
      await _importerDepuisBaseExterne();
    }
  }

  Future<void> _importerDepuisBaseActuelle() async {
    // Récupérer tous les achats avec leurs détails
    final achatsAvecDetails = <Map<String, dynamic>>[];

    for (final numAchat in _achatsNumbers) {
      final details = await (_databaseService.database.select(
        _databaseService.database.detachats,
      )..where((d) => d.numachats.equals(numAchat))).get();

      if (details.isNotEmpty) {
        achatsAvecDetails.add({
          'numAchat': numAchat,
          'statut': _achatsStatuts[numAchat] ?? 'BROUILLARD',
          'nbLignes': details.length,
        });
      }
    }

    if (achatsAvecDetails.isEmpty && mounted) {
      _scaffoldMessengerKey.currentState?.showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          margin: EdgeInsets.only(
            bottom: MediaQuery.of(context).size.height * 0.8,
            right: 20,
            left: MediaQuery.of(context).size.width * 0.75,
          ),
          content: const Text('Aucun achat avec des lignes trouvé'),
        ),
      );
      return;
    }

    // Afficher la liste des achats pour sélection
    final selectedAchat = mounted
        ? await showDialog<String>(
            context: context,
            builder: (context) => AlertDialog(
              title: const Text('Sélectionner un achat'),
              content: SizedBox(
                width: 300,
                height: 400,
                child: ListView.builder(
                  itemCount: achatsAvecDetails.length,
                  itemBuilder: (context, index) {
                    final achat = achatsAvecDetails[index];
                    return ListTile(
                      title: Text('N° ${achat['numAchat']}'),
                      subtitle: Text('${achat['nbLignes']} lignes - ${achat['statut']}'),
                      onTap: () => Navigator.of(context).pop(achat['numAchat']),
                    );
                  },
                ),
              ),
              actions: [
                TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Annuler')),
              ],
            ),
          )
        : null;

    if (selectedAchat != null) {
      await _copierLignesAchat(selectedAchat);
    }
  }

  Future<void> _copierLignesAchat(String numAchatSource) async {
    try {
      final details = await (_databaseService.database.select(
        _databaseService.database.detachats,
      )..where((d) => d.numachats.equals(numAchatSource))).get();

      if (details.isEmpty && mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: const Text('Aucune ligne trouvée pour cet achat'),
          ),
        );
        return;
      }

      // Vérifier si des articles existent encore
      final lignesValides = <Map<String, dynamic>>[];
      for (final detail in details) {
        final articleExiste = _articles.any((a) => a.designation == detail.designation);
        if (articleExiste) {
          lignesValides.add({
            'designation': detail.designation ?? '',
            'unites': detail.unites ?? '',
            'quantite': detail.q ?? 0.0,
            'prixUnitaire': detail.pu ?? 0.0,
            'montant': (detail.q ?? 0.0) * (detail.pu ?? 0.0),
            'depot': detail.depots ?? 'MAG',
          });
        }
      }

      if (lignesValides.isEmpty && mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: const Text('Aucun article de cet achat n\'existe plus'),
          ),
        );
        return;
      }

      // Confirmation avant importation
      final confirm = mounted
          ? await showDialog<bool>(
              context: context,
              builder: (context) => AlertDialog(
                title: const Text('Confirmation'),
                content: Text(
                  'Importer ${lignesValides.length} lignes de l\'achat N° $numAchatSource ?\n\nCela remplacera les lignes actuelles.',
                ),
                actions: [
                  TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Annuler')),
                  TextButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Importer')),
                ],
              ),
            )
          : null;

      if (confirm == true) {
        setState(() {
          _lignesAchat.clear();
          _lignesAchat.addAll(lignesValides);
        });
        _calculerTotaux();

        if (mounted) {
          _scaffoldMessengerKey.currentState?.showSnackBar(
            SnackBar(
              behavior: SnackBarBehavior.floating,
              margin: EdgeInsets.only(
                bottom: MediaQuery.of(context).size.height * 0.8,
                right: 20,
                left: MediaQuery.of(context).size.width * 0.75,
              ),
              content: Text('${lignesValides.length} lignes importées avec succès'),
            ),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: Text('Erreur lors de l\'importation: $e'),
          ),
        );
      }
    }
  }

  Future<void> _importerDepuisBaseExterne() async {
    try {
      // Sélectionner le fichier de base de données
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['db', 'sqlite', 'sqlite3'],
        dialogTitle: 'Sélectionner une base de données',
      );

      if (result == null || result.files.isEmpty) return;

      final filePath = result.files.first.path;
      if (filePath == null) {
        if (mounted) {
          _scaffoldMessengerKey.currentState?.showSnackBar(
            SnackBar(
              behavior: SnackBarBehavior.floating,
              margin: EdgeInsets.only(
                bottom: MediaQuery.of(context).size.height * 0.8,
                right: 20,
                left: MediaQuery.of(context).size.width * 0.75,
              ),
              content: const Text('Erreur: Chemin de fichier invalide'),
            ),
          );
        }
        return;
      }

      debugPrint('Tentative d\'ouverture de la base externe: $filePath');

      // Ouvrir la base externe
      final externalDbService = DatabaseService.fromPath(filePath);
      await externalDbService.initialize();
      debugPrint('Base externe initialisée avec succès');
      // Vérifier les tables disponibles dans la base externe
      try {
        final tablesResult = await externalDbService.database
            .customSelect("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name")
            .get();
        final tableNames = tablesResult.map((row) => row.read<String>('name')).toList();
        debugPrint('Tables disponibles dans la base externe: $tableNames');

        // Vérifier spécifiquement les tables achats et detachats
        final hasAchats = tableNames.contains('achats');
        final hasDetachats = tableNames.contains('detachats');
        debugPrint('Table achats présente: $hasAchats');
        debugPrint('Table detachats présente: $hasDetachats');

        if (!hasAchats) {
          if (mounted) {
            _scaffoldMessengerKey.currentState?.showSnackBar(
              SnackBar(
                behavior: SnackBarBehavior.floating,
                margin: EdgeInsets.only(
                  bottom: MediaQuery.of(context).size.height * 0.8,
                  right: 20,
                  left: MediaQuery.of(context).size.width * 0.75,
                ),
                content: const Text('La table "achats" n\'existe pas dans la base externe'),
              ),
            );
          }
          await externalDbService.database.close();
          return;
        }

        if (!hasDetachats) {
          if (mounted) {
            _scaffoldMessengerKey.currentState?.showSnackBar(
              SnackBar(
                behavior: SnackBarBehavior.floating,
                margin: EdgeInsets.only(
                  bottom: MediaQuery.of(context).size.height * 0.8,
                  right: 20,
                  left: MediaQuery.of(context).size.width * 0.75,
                ),
                content: const Text('La table "detachats" n\'existe pas dans la base externe'),
              ),
            );
          }
          await externalDbService.database.close();
          return;
        }
      } catch (e) {
        debugPrint('Erreur lors de la vérification des tables: $e');
      }

      // Récupérer les achats de la base externe
      final achatsExternes = await externalDbService.database.select(externalDbService.database.achats).get();
      debugPrint('Nombre d\'achats trouvés dans la base externe: ${achatsExternes.length}');

      // Vérifier aussi la table detachats pour s'assurer qu'il y a des détails
      final detailsExternes = await externalDbService.database
          .select(externalDbService.database.detachats)
          .get();
      debugPrint('Nombre de détails d\'achats trouvés: ${detailsExternes.length}');

      // Afficher quelques exemples d'achats pour debug
      if (achatsExternes.isNotEmpty) {
        debugPrint(
          'Premier achat: numachats=${achatsExternes.first.numachats}, frns=${achatsExternes.first.frns}',
        );
      }

      if (detailsExternes.isNotEmpty) {
        debugPrint(
          'Premier détail: numachats=${detailsExternes.first.numachats}, designation=${detailsExternes.first.designation}',
        );
      }

      // Si aucun achat dans la table principale mais des détails existent, récupérer les numéros uniques
      List<String> numerosAchatsDisponibles = [];
      if (achatsExternes.isEmpty && detailsExternes.isNotEmpty) {
        debugPrint('Table achats vide, récupération des numéros depuis detachats...');
        // Récupérer les numéros d'achats uniques depuis detachats
        final numerosUniques = detailsExternes
            .map((d) => d.numachats)
            .where((numero) => numero != null && numero.isNotEmpty)
            .toSet()
            .toList();
        numerosAchatsDisponibles = numerosUniques.cast<String>();
        debugPrint('Numéros d\'achats trouvés dans detachats: ${numerosAchatsDisponibles.length}');
      } else if (achatsExternes.isNotEmpty) {
        numerosAchatsDisponibles = achatsExternes
            .map((a) => a.numachats)
            .where((numero) => numero != null && numero.isNotEmpty)
            .cast<String>()
            .toList();
      }

      if (numerosAchatsDisponibles.isEmpty) {
        if (mounted) {
          _scaffoldMessengerKey.currentState?.showSnackBar(
            SnackBar(
              behavior: SnackBarBehavior.floating,
              margin: EdgeInsets.only(
                bottom: MediaQuery.of(context).size.height * 0.8,
                right: 20,
                left: MediaQuery.of(context).size.width * 0.75,
              ),
              content: const Text('Aucun achat trouvé dans la base externe'),
            ),
          );
        }
        await externalDbService.database.close();
        return;
      }

      // Afficher la liste des achats pour sélection
      final selectedAchat = mounted
          ? await showDialog<String>(
              context: context,
              builder: (context) => AlertDialog(
                title: const Text('Sélectionner un achat'),
                content: SizedBox(
                  width: 300,
                  height: 400,
                  child: ListView.builder(
                    itemCount: numerosAchatsDisponibles.length,
                    itemBuilder: (context, index) {
                      final numeroAchat = numerosAchatsDisponibles[index];
                      // Chercher les détails pour ce numéro d'achat
                      final detailsPourAchat = detailsExternes
                          .where((d) => d.numachats == numeroAchat)
                          .toList();
                      final nbLignes = detailsPourAchat.length;

                      // Essayer de trouver l'achat principal si disponible
                      final achatPrincipal = achatsExternes
                          .where((a) => a.numachats == numeroAchat)
                          .firstOrNull;

                      return ListTile(
                        title: Text('N° $numeroAchat'),
                        subtitle: Text(
                          achatPrincipal != null
                              ? '${achatPrincipal.frns ?? ""} - ${achatPrincipal.nfact ?? ""} - $nbLignes ligne(s)'
                              : 'Détails uniquement - $nbLignes ligne(s) disponible(s)',
                        ),
                        onTap: () => Navigator.of(context).pop(numeroAchat),
                      );
                    },
                  ),
                ),
                actions: [
                  TextButton(onPressed: () => Navigator.of(context).pop(), child: const Text('Annuler')),
                ],
              ),
            )
          : null;

      if (selectedAchat != null) {
        debugPrint('Achat sélectionné pour importation: $selectedAchat');
        await _copierLignesAchatExterne(externalDbService, selectedAchat);
      } else {
        debugPrint('Aucun achat sélectionné pour importation');
      }

      // Fermer la base externe
      await externalDbService.database.close();
      debugPrint('Base externe fermée');
    } catch (e) {
      debugPrint('ERREUR lors de l\'importation depuis base externe: $e');
      debugPrint('Stack trace: ${StackTrace.current}');
      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: Text('Erreur lors de l\'importation: $e'),
          ),
        );
      }
    }
  }

  Future<void> _copierLignesAchatExterne(DatabaseService externalDb, String numAchatSource) async {
    try {
      debugPrint('=== DéBUT COPIE LIGNES ACHAT EXTERNE ===');
      debugPrint('Numéro achat source: $numAchatSource');

      final details = await (externalDb.database.select(
        externalDb.database.detachats,
      )..where((d) => d.numachats.equals(numAchatSource))).get();

      debugPrint('Nombre de détails trouvés pour l\'achat $numAchatSource: ${details.length}');

      if (details.isNotEmpty) {
        debugPrint(
          'Premier détail: designation=${details.first.designation}, q=${details.first.q}, pu=${details.first.pu}',
        );
      }

      if (details.isEmpty) {
        debugPrint('ERREUR: Aucune ligne trouvée pour l\'achat $numAchatSource');
        if (mounted) {
          _scaffoldMessengerKey.currentState?.showSnackBar(
            SnackBar(
              behavior: SnackBarBehavior.floating,
              margin: EdgeInsets.only(
                bottom: MediaQuery.of(context).size.height * 0.8,
                right: 20,
                left: MediaQuery.of(context).size.width * 0.75,
              ),
              content: const Text('Aucune ligne trouvée pour cet achat'),
            ),
          );
        }
        return;
      }

      // Vérifier si des articles existent dans la base actuelle
      final lignesValides = <Map<String, dynamic>>[];
      final articlesNonTrouves = <String>[];

      debugPrint('Vérification des articles dans la base actuelle...');
      debugPrint('Nombre d\'articles dans la base actuelle: ${_articles.length}');

      for (final detail in details) {
        final designation = detail.designation ?? '';
        final articleExiste = _articles.any((a) => a.designation == designation);

        debugPrint('Article "$designation" existe dans base actuelle: $articleExiste');

        if (articleExiste) {
          lignesValides.add({
            'designation': designation,
            'unites': detail.unites ?? '',
            'quantite': detail.q ?? 0.0,
            'prixUnitaire': detail.pu ?? 0.0,
            'montant': (detail.q ?? 0.0) * (detail.pu ?? 0.0),
            'depot': detail.depots ?? 'MAG',
          });
        } else {
          articlesNonTrouves.add(designation);
        }
      }

      debugPrint('Lignes valides: ${lignesValides.length}');
      debugPrint('Articles non trouvés: $articlesNonTrouves');

      if (lignesValides.isEmpty) {
        debugPrint('ERREUR: Aucun article de cet achat n\'existe dans la base actuelle');
        if (mounted) {
          _scaffoldMessengerKey.currentState?.showSnackBar(
            SnackBar(
              behavior: SnackBarBehavior.floating,
              margin: EdgeInsets.only(
                bottom: MediaQuery.of(context).size.height * 0.8,
                right: 20,
                left: MediaQuery.of(context).size.width * 0.75,
              ),
              content: Text(
                'Aucun article de cet achat n\'existe dans la base actuelle.\nArticles manquants: ${articlesNonTrouves.join(", ")}',
              ),
            ),
          );
        }
        return;
      }

      // Confirmation avant importation
      final confirm = mounted
          ? await showDialog<bool>(
              context: context,
              builder: (context) => AlertDialog(
                title: const Text('Confirmation'),
                content: Text(
                  'Importer ${lignesValides.length} lignes de l\'achat N° $numAchatSource ?\n\nCela remplacera les lignes actuelles.',
                ),
                actions: [
                  TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Annuler')),
                  TextButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Importer')),
                ],
              ),
            )
          : null;

      if (confirm == true) {
        debugPrint('Confirmation reçue, importation des lignes...');
        setState(() {
          _lignesAchat.clear();
          _lignesAchat.addAll(lignesValides);
        });
        _calculerTotaux();
        debugPrint('Lignes importées et totaux recalculés');

        if (mounted) {
          _scaffoldMessengerKey.currentState?.showSnackBar(
            SnackBar(
              behavior: SnackBarBehavior.floating,
              margin: EdgeInsets.only(
                bottom: MediaQuery.of(context).size.height * 0.8,
                right: 20,
                left: MediaQuery.of(context).size.width * 0.75,
              ),
              content: Text('${lignesValides.length} lignes importées avec succès'),
            ),
          );
        }
      } else {
        debugPrint('Importation annulée par l\'utilisateur');
      }
      debugPrint('=== FIN COPIE LIGNES ACHAT EXTERNE ===');
    } catch (e) {
      debugPrint('ERREUR lors de la copie des lignes externes: $e');
      debugPrint('Stack trace: ${StackTrace.current}');
      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: Text('Erreur lors de l\'importation: $e'),
          ),
        );
      }
    }
  }

  Future<void> _creerNouvelAchat() async {
    debugPrint('=== DéBUT CRéATION NOUVEL ACHAT ===');
    setState(() {
      _isExistingPurchase = false;
      _selectedRowIndex = null;
      _lignesAchat.clear();
      _selectedFournisseur = null;
      _selectedModePaiement = null;
      _selectedStatut = 'Brouillard';
      _statutAchatActuel = null;
    });
    debugPrint('Variables d\'état réinitialisées');

    // Réinitialiser tous les contrôleurs
    _nFactController.clear();
    _fournisseurController.clear();
    _totalTTCController.text = '0';
    _totalFMGController.text = '0';
    debugPrint('Contrôleurs réinitialisés');

    // Mode de paiement par défaut "A crédit"
    _selectedModePaiement = 'A crédit';

    // échéance par défaut = date actuelle
    final now = DateTime.now();
    _echeanceController.text = app_date.AppDateUtils.formatDate(now);

    _resetArticleForm();

    // Générer un nouveau numéro d'achat SEULEMENT pour un nouvel achat
    final nextNum = await _getNextNumAchats();
    _numAchatsController.text = nextNum;
    debugPrint('Nouveau numéro d\'achat généré: $nextNum');

    // Remettre la date d'aujourd'hui
    _dateController.text = app_date.AppDateUtils.formatDate(now);

    // Focus automatique sur N° Facture/BL
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _nFactFocusNode.requestFocus();
    });
    debugPrint('=== FIN CRéATION NOUVEL ACHAT ===');
  }

  Future<void> _validerAchat() async {
    debugPrint('=== DéBUT VALIDATION ACHAT ===');
    debugPrint('Fournisseur sélectionné: $_selectedFournisseur');
    debugPrint('N° Facture: ${_nFactController.text}');
    debugPrint('Nombre de lignes: ${_lignesAchat.length}');
    debugPrint('Statut sélectionné: $_selectedStatut');
    debugPrint('Mode achat existant: $_isExistingPurchase');

    if (_selectedFournisseur == null || _nFactController.text.isEmpty || _lignesAchat.isEmpty) {
      debugPrint('ERREUR: Données manquantes pour la validation');
      _scaffoldMessengerKey.currentState?.showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          margin: EdgeInsets.only(
            bottom: MediaQuery.of(context).size.height * 0.8,
            right: 20,
            left: MediaQuery.of(context).size.width * 0.75,
          ),
          content: const Text(
            'Veuillez sélectionner un fournisseur, saisir le N° Facture/BL et ajouter des articles',
          ),
        ),
      );
      return;
    }

    try {
      debugPrint('Vérification de l\'existence du numéro d\'achat: ${_numAchatsController.text}');
      // Vérifier si le numéro d'achat existe déjÃ
      final existingAchat = await (_databaseService.database.select(
        _databaseService.database.achats,
      )..where((a) => a.numachats.equals(_numAchatsController.text))).getSingleOrNull();
      debugPrint('Achat existant trouvé: ${existingAchat != null}');

      if (existingAchat != null) {
        debugPrint('ERREUR: Numéro d\'achat déjÃ  existant');
        if (mounted) {
          _scaffoldMessengerKey.currentState?.showSnackBar(
            SnackBar(
              behavior: SnackBarBehavior.floating,
              margin: EdgeInsets.only(
                bottom: MediaQuery.of(context).size.height * 0.8,
                right: 20,
                left: MediaQuery.of(context).size.width * 0.75,
              ),
              content: Text('Le N° Achats ${_numAchatsController.text} existe déjÃ '),
            ),
          );
        }
        return;
      }

      // Convertir la date au format DateTime
      List<String> dateParts = _dateController.text.split('-');
      DateTime dateForDB = DateTime(
        int.parse(dateParts[2]),
        int.parse(dateParts[1]),
        int.parse(dateParts[0]),
      );

      // Calculer la date d'échéance
      DateTime? echeanceForDB;
      if (_echeanceController.text.isNotEmpty) {
        List<String> echeanceParts = _echeanceController.text.split('-');
        echeanceForDB = DateTime(
          int.parse(echeanceParts[2]),
          int.parse(echeanceParts[1]),
          int.parse(echeanceParts[0]),
        );
      }

      double totalTTC = double.tryParse(_totalTTCController.text.replaceAll(' ', '')) ?? 0.0;

      // Préparer les données de l'achat
      final lignesAchatData = _lignesAchat
          .map(
            (ligne) => {
              'designation': ligne['designation'],
              'unite': ligne['unites'],
              'depot': ligne['depot'],
              'quantite': ligne['quantite'],
              'prixUnitaire': ligne['prixUnitaire'],
            },
          )
          .toList();

      // Utiliser AchatService selon le mode
      debugPrint('Traitement selon le mode: $_selectedStatut');
      if (_selectedStatut == 'Journal') {
        debugPrint('Appel du service traiterAchatJournal');
        await _achatService.traiterAchatJournal(
          numAchats: _numAchatsController.text,
          nFacture: _nFactController.text.isEmpty ? null : _nFactController.text,
          date: dateForDB,
          fournisseur: _selectedFournisseur,
          modePaiement: _selectedModePaiement,
          echeance: echeanceForDB,
          totalTTC: totalTTC,
          lignesAchat: lignesAchatData,
        );
        debugPrint('Service traiterAchatJournal terminé');
      } else {
        debugPrint('Appel du service traiterAchatBrouillard');
        await _achatService.traiterAchatBrouillard(
          numAchats: _numAchatsController.text,
          nFacture: _nFactController.text.isEmpty ? null : _nFactController.text,
          date: dateForDB,
          fournisseur: _selectedFournisseur,
          modePaiement: _selectedModePaiement,
          echeance: echeanceForDB,
          totalTTC: totalTTC,
          lignesAchat: lignesAchatData,
        );
        debugPrint('Service traiterAchatBrouillard terminé');
      }

      // Recharger la liste des achats
      debugPrint('Rechargement de la liste des achats');
      await _loadAchatsNumbers();
      debugPrint('Liste des achats rechargée');

      if (mounted) {
        final message = _selectedStatut == 'Journal'
            ? 'Achat enregistré et validé avec succès'
            : 'Achat enregistré en brouillard';
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: Text(message),
          ),
        );
        if (_selectedStatut == 'Journal') {
          debugPrint('Fermeture du modal après enregistrement journal');
          Navigator.of(context).pop();
        } else {
          debugPrint('Création d\'un nouvel achat après enregistrement brouillard');
          await _creerNouvelAchat();
        }
      }
      debugPrint('=== FIN VALIDATION ACHAT RéUSSIE ===');
    } catch (e) {
      debugPrint('ERREUR lors de l\'enregistrement: $e');
      debugPrint('Stack trace: ${StackTrace.current}');
      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: SelectableText('Erreur lors de l\'enregistrement: $e'),
            duration: const Duration(seconds: 15),
          ),
        );
      }
    }
  }

  PdfPageFormat get _pdfPageFormat {
    switch (_selectedFormat) {
      case 'A4':
        return PdfPageFormat.a4;
      case 'A6':
        return PdfPageFormat.a6;
      default:
        return PdfPageFormat.a5; // A5
    }
  }

  Future<void> _imprimerBonReception() async {
    if (_lignesAchat.isEmpty) {
      _scaffoldMessengerKey.currentState?.showSnackBar(
        SnackBar(
          behavior: SnackBarBehavior.floating,
          margin: EdgeInsets.only(
            bottom: MediaQuery.of(context).size.height * 0.8,
            right: 20,
            left: MediaQuery.of(context).size.width * 0.75,
          ),
          content: const Text('Aucun article à  imprimer'),
        ),
      );
      return;
    }

    try {
      final pdf = await _generateBonReceptionPdf();
      final bytes = await pdf.save();

      final printers = await Printing.listPrinters();
      final defaultPrinter = printers.where((p) => p.isDefault).firstOrNull;

      if (defaultPrinter != null) {
        await Printing.directPrintPdf(
          printer: defaultPrinter,
          onLayout: (PdfPageFormat format) async => bytes,
          name: 'BR_${_numAchatsController.text}_${_dateController.text.replaceAll('/', '-')}.pdf',
          format: _selectedFormat == 'A4'
              ? PdfPageFormat.a4
              : (_selectedFormat == 'A6' ? PdfPageFormat.a6 : PdfPageFormat.a5),
        );
      } else {
        await Printing.layoutPdf(
          onLayout: (PdfPageFormat format) async => bytes,
          name: 'BR_${_numAchatsController.text}_${_dateController.text.replaceAll('/', '-')}.pdf',
          format: _selectedFormat == 'A4'
              ? PdfPageFormat.a4
              : (_selectedFormat == 'A6' ? PdfPageFormat.a6 : PdfPageFormat.a5),
        );
      }

      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: const Text('Bon de réception envoyé à  l\'imprimante par défaut'),
          ),
        );
      }
    } catch (e) {
      if (mounted) {
        _scaffoldMessengerKey.currentState?.showSnackBar(
          SnackBar(
            behavior: SnackBarBehavior.floating,
            margin: EdgeInsets.only(
              bottom: MediaQuery.of(context).size.height * 0.8,
              right: 20,
              left: MediaQuery.of(context).size.width * 0.75,
            ),
            content: Text('Erreur d\'impression: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<pw.Document> _generateBonReceptionPdf() async {
    final pdf = pw.Document();
    final pdfFontSize = _selectedFormat == 'A6' ? 8.0 : (_selectedFormat == 'A5' ? 10.0 : 12.0);
    final pdfHeaderFontSize = _selectedFormat == 'A6' ? 8.0 : (_selectedFormat == 'A5' ? 10.0 : 12.0);
    final pdfPadding = _selectedFormat == 'A6' ? 8.0 : (_selectedFormat == 'A5' ? 10.0 : 12.0);

    // Calculer le nombre de lignes par page
    final int maxLinesPerPage = _selectedFormat == 'A6' ? 25 : (_selectedFormat == 'A5' ? 30 : 35);
    final int articlePages = (_lignesAchat.length / maxLinesPerPage).ceil().clamp(1, double.infinity).toInt();

    // Calculer l'espace disponible sur la dernière page en lignes équivalentes
    final int lastPageLines = _lignesAchat.isEmpty
        ? 0
        : (_lignesAchat.length % maxLinesPerPage == 0
              ? maxLinesPerPage
              : _lignesAchat.length % maxLinesPerPage);
    final int emptyLinesOnLastPage = maxLinesPerPage - lastPageLines;

    // Estimation de l'espace nécessaire en nombre de lignes équivalentes
    final int totalsEquivalentLines = _selectedFormat == 'A6' ? 8 : (_selectedFormat == 'A5' ? 7 : 6);
    final int signaturesEquivalentLines = _selectedFormat == 'A6' ? 5 : (_selectedFormat == 'A5' ? 4 : 4);

    bool canFitTotalsOnLastPage = emptyLinesOnLastPage >= totalsEquivalentLines;
    bool canFitBothOnLastPage = emptyLinesOnLastPage >= (totalsEquivalentLines + signaturesEquivalentLines);

    int totalPages = articlePages;
    if (!canFitTotalsOnLastPage) {
      totalPages += 1; // Page séparée pour totaux et signatures
    } else if (!canFitBothOnLastPage) {
      totalPages += 1; // Page séparée pour signatures seulement
    }

    // Pages avec articles
    for (int pageIndex = 0; pageIndex < articlePages; pageIndex++) {
      final int startIndex = pageIndex * maxLinesPerPage;
      final int endIndex = (startIndex + maxLinesPerPage).clamp(0, _lignesAchat.length);
      final List<Map<String, dynamic>> pageLines = _lignesAchat.sublist(startIndex, endIndex);
      final bool isLastArticlePage = pageIndex == articlePages - 1;

      pdf.addPage(
        pw.Page(
          pageFormat: _pdfPageFormat,
          margin: const pw.EdgeInsets.all(3),
          build: (context) {
            return pw.Center(
              child: pw.Container(
                alignment: pw.Alignment.topCenter,
                padding: pw.EdgeInsets.all(pdfPadding),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    // Document title centered
                    pw.Center(
                      child: pw.Container(
                        padding: pw.EdgeInsets.symmetric(vertical: pdfPadding / 2),
                        decoration: const pw.BoxDecoration(
                          border: pw.Border(
                            top: pw.BorderSide(color: PdfColors.black, width: 2),
                            bottom: pw.BorderSide(color: PdfColors.black, width: 2),
                          ),
                        ),
                        child: pw.Text(
                          'BON DE RéCEPTION',
                          style: pw.TextStyle(
                            fontWeight: pw.FontWeight.bold,
                            fontSize: pdfHeaderFontSize + 2,
                          ),
                        ),
                      ),
                    ),

                    pw.SizedBox(height: pdfPadding),

                    // Header section with company and document info
                    pw.Container(
                      decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.black, width: 1)),
                      padding: pw.EdgeInsets.all(pdfPadding / 2),
                      child: pw.Row(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Expanded(
                            flex: 3,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                pw.Text(
                                  'SOCIéTé:',
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: pdfFontSize - 1,
                                  ),
                                ),
                                pw.Text(
                                  _societe?.rsoc ?? 'SOCIéTé',
                                  style: pw.TextStyle(fontSize: pdfFontSize, fontWeight: pw.FontWeight.bold),
                                ),
                                if (_societe?.activites != null)
                                  pw.Text(
                                    _societe!.activites!,
                                    style: pw.TextStyle(fontSize: pdfFontSize - 1),
                                  ),
                                if (_societe?.adr != null)
                                  pw.Text(_societe!.adr!, style: pw.TextStyle(fontSize: pdfFontSize - 1)),
                              ],
                            ),
                          ),
                          pw.Expanded(
                            flex: 2,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                _buildPdfInfoRow('N° DOCUMENT:', _numAchatsController.text, pdfFontSize),
                                _buildPdfInfoRow('DATE:', _dateController.text, pdfFontSize),
                                _buildPdfInfoRow('N° FACTURE/BL:', _nFactController.text, pdfFontSize),
                                _buildPdfInfoRow('FOURNISSEUR:', _selectedFournisseur ?? "", pdfFontSize),
                                if (totalPages > 1)
                                  _buildPdfInfoRow('PAGE:', '${pageIndex + 1}/$totalPages', pdfFontSize),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    pw.SizedBox(height: pdfPadding),

                    // Articles table
                    pw.Container(
                      decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.black, width: 0.5)),
                      child: pw.Column(
                        children: [
                          // Table header
                          pw.Container(
                            color: PdfColors.grey300,
                            child: pw.Table(
                              border: const pw.TableBorder(
                                horizontalInside: pw.BorderSide(color: PdfColors.black, width: 0.5),
                                verticalInside: pw.BorderSide(color: PdfColors.black, width: 0.5),
                              ),
                              columnWidths: const {
                                0: pw.FlexColumnWidth(1),
                                1: pw.FlexColumnWidth(3),
                                2: pw.FlexColumnWidth(1),
                                3: pw.FlexColumnWidth(1),
                                4: pw.FlexColumnWidth(1),
                                5: pw.FlexColumnWidth(1.5),
                                6: pw.FlexColumnWidth(3),
                              },
                              children: [
                                pw.TableRow(
                                  children: [
                                    _buildPdfTableCell('N°', pdfFontSize, isHeader: true),
                                    _buildPdfTableCell('DéSIGNATION', pdfFontSize, isHeader: true),
                                    _buildPdfTableCell('DéP', pdfFontSize, isHeader: true),
                                    _buildPdfTableCell('QTé', pdfFontSize, isHeader: true),
                                    _buildPdfTableCell('U', pdfFontSize, isHeader: true),
                                    _buildPdfTableCell('PU HT', pdfFontSize, isHeader: true),
                                    _buildPdfTableCell('MONTANT', pdfFontSize, isHeader: true),
                                  ],
                                ),
                              ],
                            ),
                          ),
                          // Table data
                          pw.Table(
                            border: const pw.TableBorder(
                              horizontalInside: pw.BorderSide(color: PdfColors.black, width: 0.5),
                              verticalInside: pw.BorderSide(color: PdfColors.black, width: 0.5),
                            ),
                            columnWidths: const {
                              0: pw.FlexColumnWidth(1),
                              1: pw.FlexColumnWidth(3),
                              2: pw.FlexColumnWidth(1),
                              3: pw.FlexColumnWidth(1),
                              4: pw.FlexColumnWidth(1),
                              5: pw.FlexColumnWidth(1.5),
                              6: pw.FlexColumnWidth(3),
                            },
                            children: [
                              ...pageLines.asMap().entries.map((entry) {
                                final globalIndex = startIndex + entry.key + 1;
                                final ligne = entry.value;
                                return pw.TableRow(
                                  children: [
                                    _buildPdfTableCell(globalIndex.toString(), pdfFontSize),
                                    _buildPdfTableCell(ligne['designation'] ?? '', pdfFontSize),
                                    _buildPdfTableCell(ligne['depot'] ?? '', isAmount: true, pdfFontSize),
                                    _buildPdfTableCell(
                                      AppFunctions.formatNumber(ligne['quantite']?.toDouble() ?? 0),
                                      pdfFontSize,
                                    ),
                                    _buildPdfTableCell(ligne['unites'] ?? '', pdfFontSize),
                                    _buildPdfTableCell(
                                      AppFunctions.formatNumber(ligne['prixUnitaire']?.toDouble() ?? 0),
                                      isAmount: true,
                                      pdfFontSize,
                                    ),
                                    _buildPdfTableCell(
                                      AppFunctions.formatNumber(ligne['montant']?.toDouble() ?? 0),
                                      pdfFontSize,
                                      isAmount: true,
                                    ),
                                  ],
                                );
                              }),
                            ],
                          ),
                        ],
                      ),
                    ),

                    // Ajouter totaux sur la dernière page d'articles si possible
                    if (isLastArticlePage && canFitTotalsOnLastPage) ...[
                      pw.SizedBox(height: pdfPadding * 2),
                      _buildTotalsSection(pdfFontSize, pdfPadding),
                    ],

                    // Ajouter signatures sur la dernière page si possible
                    if (isLastArticlePage && canFitBothOnLastPage) ...[
                      pw.SizedBox(height: pdfPadding * 2),
                      _buildSignaturesSection(pdfFontSize, pdfPadding),
                    ],
                  ],
                ),
              ),
            );
          },
        ),
      );
    }

    // Page séparée pour totaux et/ou signatures si nécessaire
    if (!canFitTotalsOnLastPage || (!canFitBothOnLastPage && canFitTotalsOnLastPage)) {
      pdf.addPage(
        pw.Page(
          pageFormat: _pdfPageFormat,
          margin: const pw.EdgeInsets.all(3),
          build: (context) {
            return pw.Center(
              child: pw.Container(
                alignment: pw.Alignment.topCenter,
                padding: pw.EdgeInsets.all(pdfPadding),
                child: pw.Column(
                  crossAxisAlignment: pw.CrossAxisAlignment.start,
                  children: [
                    // Document title centered
                    pw.Center(
                      child: pw.Container(
                        padding: pw.EdgeInsets.symmetric(vertical: pdfPadding / 2),
                        decoration: const pw.BoxDecoration(
                          border: pw.Border(
                            top: pw.BorderSide(color: PdfColors.black, width: 2),
                            bottom: pw.BorderSide(color: PdfColors.black, width: 2),
                          ),
                        ),
                        child: pw.Text(
                          'BON DE RéCEPTION',
                          style: pw.TextStyle(
                            fontWeight: pw.FontWeight.bold,
                            fontSize: pdfHeaderFontSize + 2,
                          ),
                        ),
                      ),
                    ),

                    pw.SizedBox(height: pdfPadding),

                    // Header section with company and document info
                    pw.Container(
                      decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.black, width: 1)),
                      padding: pw.EdgeInsets.all(pdfPadding / 2),
                      child: pw.Row(
                        crossAxisAlignment: pw.CrossAxisAlignment.start,
                        children: [
                          pw.Expanded(
                            flex: 3,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                pw.Text(
                                  'SOCIéTé:',
                                  style: pw.TextStyle(
                                    fontWeight: pw.FontWeight.bold,
                                    fontSize: pdfFontSize - 1,
                                  ),
                                ),
                                pw.Text(
                                  _societe?.rsoc ?? 'SOCIéTé',
                                  style: pw.TextStyle(fontSize: pdfFontSize, fontWeight: pw.FontWeight.bold),
                                ),
                                if (_societe?.activites != null)
                                  pw.Text(
                                    _societe!.activites!,
                                    style: pw.TextStyle(fontSize: pdfFontSize - 1),
                                  ),
                                if (_societe?.adr != null)
                                  pw.Text(_societe!.adr!, style: pw.TextStyle(fontSize: pdfFontSize - 1)),
                              ],
                            ),
                          ),
                          pw.Expanded(
                            flex: 2,
                            child: pw.Column(
                              crossAxisAlignment: pw.CrossAxisAlignment.start,
                              children: [
                                _buildPdfInfoRow('N° DOCUMENT:', _numAchatsController.text, pdfFontSize),
                                _buildPdfInfoRow('DATE:', _dateController.text, pdfFontSize),
                                _buildPdfInfoRow('N° FACTURE:', _nFactController.text, pdfFontSize),
                                _buildPdfInfoRow('FOURNISSEUR:', _selectedFournisseur ?? "", pdfFontSize),
                                _buildPdfInfoRow('PAGE:', '$totalPages/$totalPages', pdfFontSize),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),

                    pw.SizedBox(height: pdfPadding * 2),

                    // Totaux si pas déjÃ  sur la dernière page d'articles
                    if (!canFitTotalsOnLastPage) _buildTotalsSection(pdfFontSize, pdfPadding),

                    pw.SizedBox(height: pdfPadding * 2),

                    // Signatures
                    _buildSignaturesSection(pdfFontSize, pdfPadding),
                  ],
                ),
              ),
            );
          },
        ),
      );
    }

    return pdf;
  }

  @override
  void dispose() {
    _globalFocusTimer?.cancel();
    _globalShortcutsFocusNode.dispose();
    _autocompleteController?.dispose();
    _numAchatsController.dispose();
    _nFactController.dispose();
    _dateController.dispose();
    _fournisseurController.dispose();
    _modePaiementController.dispose();
    _echeanceController.dispose();
    _totalTTCController.dispose();
    _totalFMGController.dispose();
    _articleSearchController.dispose();
    _uniteController.dispose();
    _depotController.dispose();
    _quantiteController.dispose();
    _prixController.dispose();
    _searchAchatsController.dispose();
    _echeanceJoursController.dispose();
    super.dispose();
  }

  pw.Widget _buildTotalsSection(double pdfFontSize, double pdfPadding) {
    return pw.Container(
      decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.black, width: 1)),
      padding: pw.EdgeInsets.all(pdfPadding / 2),
      child: pw.Column(
        children: [
          pw.Row(
            children: [
              pw.Spacer(),
              pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.end,
                children: [
                  pw.Container(
                    decoration: const pw.BoxDecoration(
                      border: pw.Border(top: pw.BorderSide(color: PdfColors.black)),
                    ),
                    child: _buildPdfTotalRow(
                      'TOTAL TTC:',
                      AppFunctions.formatNumber(
                        double.tryParse(_totalTTCController.text.replaceAll(' ', '')) ?? 0,
                      ),
                      pdfFontSize,
                      isBold: true,
                    ),
                  ),
                ],
              ),
            ],
          ),
          pw.SizedBox(height: pdfPadding / 2),
          pw.Container(
            width: double.infinity,
            padding: pw.EdgeInsets.all(pdfPadding / 2),
            decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.black, width: 0.5)),
            alignment: pw.Alignment.center,
            child: pw.Text(
              'ArrÃªté à  la somme de ${AppFunctions.numberToWords((double.tryParse(_totalTTCController.text.replaceAll(' ', '')) ?? 0).round())} Ariary',
              style: pw.TextStyle(fontSize: pdfFontSize - 1, fontWeight: pw.FontWeight.bold),
            ),
          ),
          pw.SizedBox(height: pdfPadding / 2),
          pw.Row(
            children: [
              pw.Text(
                'Mode de paiement: ',
                style: pw.TextStyle(fontWeight: pw.FontWeight.bold, fontSize: pdfFontSize - 1),
              ),
              pw.Text(_selectedModePaiement ?? "", style: pw.TextStyle(fontSize: pdfFontSize - 1)),
            ],
          ),
        ],
      ),
    );
  }

  pw.Widget _buildSignaturesSection(double pdfFontSize, double pdfPadding) {
    return pw.Container(
      decoration: pw.BoxDecoration(border: pw.Border.all(color: PdfColors.black, width: 1)),
      padding: pw.EdgeInsets.all(pdfPadding),
      child: pw.Row(
        children: [
          pw.Expanded(
            child: pw.Column(
              children: [
                pw.Text(
                  'FOURNISSEUR',
                  style: pw.TextStyle(fontSize: pdfFontSize, fontWeight: pw.FontWeight.bold),
                ),
                pw.SizedBox(height: pdfPadding * 2),
                pw.Container(
                  height: 1,
                  color: PdfColors.black,
                  margin: const pw.EdgeInsets.symmetric(horizontal: 20),
                ),
                pw.SizedBox(height: pdfPadding / 2),
                pw.Text('Nom et signature', style: pw.TextStyle(fontSize: pdfFontSize - 2)),
              ],
            ),
          ),
          pw.Container(width: 1, height: 60, color: PdfColors.black),
          pw.Expanded(
            child: pw.Column(
              children: [
                pw.Text(
                  'RéCEPTIONNAIRE',
                  style: pw.TextStyle(fontSize: pdfFontSize, fontWeight: pw.FontWeight.bold),
                ),
                pw.SizedBox(height: pdfPadding * 2),
                pw.Container(
                  height: 1,
                  color: PdfColors.black,
                  margin: const pw.EdgeInsets.symmetric(horizontal: 20),
                ),
                pw.SizedBox(height: pdfPadding / 2),
                pw.Text('Nom et signature', style: pw.TextStyle(fontSize: pdfFontSize - 2)),
              ],
            ),
          ),
        ],
      ),
    );
  }

  pw.Widget _buildPdfTableCell(
    String text,
    double fontSize, {
    bool isHeader = false,
    bool isAmount = false,
    bool isPu = false,
  }) {
    return pw.Container(
      padding: pw.EdgeInsets.symmetric(
        horizontal: _selectedFormat == 'A6' ? 3 : 5,
        vertical: _selectedFormat == 'A6' ? 2 : 5,
      ),
      child: pw.Text(
        text,
        style: pw.TextStyle(
          fontSize: fontSize - 1,
          fontWeight: isHeader ? pw.FontWeight.bold : pw.FontWeight.normal,
        ),
        textAlign: isHeader
            ? pw.TextAlign.center
            : (isAmount || RegExp(r'^\d+$').hasMatch(text)
                  ? pw.TextAlign.right
                  : isPu
                  ? pw.TextAlign.right
                  : pw.TextAlign.left),
      ),
    );
  }

  pw.Widget _buildPdfInfoRow(String label, String value, double fontSize) {
    return pw.Text(
      "$label $value",
      style: pw.TextStyle(fontSize: fontSize - 1, fontWeight: pw.FontWeight.normal),
    );
  }

  pw.Widget _buildPdfTotalRow(String label, String value, double fontSize, {bool isBold = false}) {
    return pw.Padding(
      padding: const pw.EdgeInsets.symmetric(vertical: 2),
      child: pw.Row(
        children: [
          pw.Text(
            label,
            style: pw.TextStyle(
              fontSize: fontSize - 1,
              fontWeight: isBold ? pw.FontWeight.bold : pw.FontWeight.normal,
            ),
          ),
          pw.SizedBox(width: 15),
          pw.Text(
            value,
            style: pw.TextStyle(fontSize: fontSize - 1, fontWeight: pw.FontWeight.bold),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: false,
      child: Shortcuts(
        shortcuts: const <ShortcutActivator, Intent>{
          // Raccourcis globaux avec Ctrl
          SingleActivator(LogicalKeyboardKey.keyS, control: true): SavePurchaseIntent(),
          SingleActivator(LogicalKeyboardKey.keyN, control: true): NewPurchaseIntent(),
          SingleActivator(LogicalKeyboardKey.keyD, control: true): CancelPurchaseIntent(),
          SingleActivator(LogicalKeyboardKey.keyP, control: true): PrintReceiptIntent(),
          SingleActivator(LogicalKeyboardKey.keyF, control: true): SearchArticleIntent(),
          SingleActivator(LogicalKeyboardKey.keyL, control: true): LastJournalIntent(),
          SingleActivator(LogicalKeyboardKey.keyB, control: true): LastDraftIntent(),
          SingleActivator(LogicalKeyboardKey.keyX, control: true, shift: true): LastCanceledIntent(),

          // Raccourcis simples
          SingleActivator(LogicalKeyboardKey.escape): ClearFieldIntent(),
          SingleActivator(LogicalKeyboardKey.f3): ValidateIntent(),
        },
        child: Actions(
          actions: <Type, Action<Intent>>{
            SavePurchaseIntent: CallbackAction<SavePurchaseIntent>(
              onInvoke: (intent) {
                if (_isExistingPurchase && _statutAchatActuel != 'JOURNAL') {
                  _modifierAchat();
                } else if (!_isExistingPurchase) {
                  _validerAchat();
                }
                return null;
              },
            ),
            NewPurchaseIntent: CallbackAction<NewPurchaseIntent>(
              onInvoke: (intent) {
                _creerNouvelAchat();
                return null;
              },
            ),
            CancelPurchaseIntent: CallbackAction<CancelPurchaseIntent>(
              onInvoke: (intent) {
                if (_isExistingPurchase) {
                  _contrePasserAchat();
                }
                return null;
              },
            ),
            PrintReceiptIntent: CallbackAction<PrintReceiptIntent>(
              onInvoke: (intent) {
                if (_lignesAchat.isNotEmpty) {
                  _imprimerBonReception();
                }
                return null;
              },
            ),
            SearchArticleIntent: CallbackAction<SearchArticleIntent>(
              onInvoke: (intent) {
                _searchAchatsFocusNode.requestFocus();
                return null;
              },
            ),
            LastJournalIntent: CallbackAction<LastJournalIntent>(
              onInvoke: (intent) {
                final journalAchats = _getJournalAchats();
                if (journalAchats.isNotEmpty) {
                  _chargerAchatExistant(journalAchats.first);
                }
                return null;
              },
            ),
            LastDraftIntent: CallbackAction<LastDraftIntent>(
              onInvoke: (intent) {
                final brouillardAchats = _getBrouillardAchats();
                if (brouillardAchats.isNotEmpty) {
                  _chargerAchatExistant(brouillardAchats.first);
                }
                return null;
              },
            ),
            LastCanceledIntent: CallbackAction<LastCanceledIntent>(
              onInvoke: (intent) {
                final contrePasseAchats = _getContrePasseAchats();
                if (contrePasseAchats.isNotEmpty) {
                  _chargerAchatExistant(contrePasseAchats.first);
                }
                return null;
              },
            ),
            ClearFieldIntent: CallbackAction<ClearFieldIntent>(
              onInvoke: (intent) {
                final currentFocus = FocusScope.of(context).focusedChild;
                if (currentFocus != null) {
                  // Vider le champ actuellement focalisé
                  if (currentFocus == _nFactFocusNode) {
                    _nFactController.clear();
                  } else if (currentFocus == _fournisseurFocusNode) {
                    _fournisseurController.clear();
                    setState(() {
                      _selectedFournisseur = null;
                    });
                  } else if (currentFocus == _articleFocusNode) {
                    setState(() {
                      _selectedArticle = null;
                    });
                  } else if (currentFocus == _uniteFocusNode) {
                    _uniteController.clear();
                  } else if (currentFocus == _quantiteFocusNode) {
                    _quantiteController.clear();
                  } else if (currentFocus == _prixFocusNode) {
                    _prixController.clear();
                  } else if (currentFocus == _depotFocusNode) {
                    _depotController.clear();
                  } else if (currentFocus == _searchAchatsFocusNode) {
                    _searchAchatsController.clear();
                    setState(() {
                      _searchAchatsText = '';
                    });
                  } else if (currentFocus == _echeanceJoursFocusNode) {
                    _echeanceJoursController.clear();
                  }
                }
                return null;
              },
            ),
            ValidateIntent: CallbackAction<ValidateIntent>(
              onInvoke: (intent) {
                if (_isExistingPurchase && _statutAchatActuel == 'BROUILLARD') {
                  _validerAchatBrouillard();
                }
                return null;
              },
            ),
          },
          child: FocusScope(
            autofocus: true,
            child: Focus(
              focusNode: _globalShortcutsFocusNode,
              canRequestFocus: true,
              descendantsAreFocusable: true,
              onKeyEvent: (node, event) {
                return KeyEventResult.ignored;
              },
              child: Dialog(
                constraints: BoxConstraints(
                  minHeight: MediaQuery.of(context).size.height * 0.8,
                  minWidth: MediaQuery.of(context).size.width * 0.9,
                  maxHeight: MediaQuery.of(context).size.height * 0.9,
                  maxWidth: MediaQuery.of(context).size.width * 0.99,
                ),
                backgroundColor: Colors.grey[100],
                child: ScaffoldMessenger(
                  key: _scaffoldMessengerKey,
                  child: Scaffold(
                    backgroundColor: Colors.transparent,
                    body: Container(
                      decoration: BoxDecoration(
                        borderRadius: const BorderRadius.all(Radius.circular(16)),
                        color: Colors.grey[100],
                      ),
                      child: Row(
                        children: [
                          // Liste des achats à  gauche
                          Container(
                            width: 250,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              border: Border(right: BorderSide(color: Colors.grey.shade300)),
                            ),
                            child: Column(
                              children: [
                                Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    color: Colors.blue.shade50,
                                    border: Border(bottom: BorderSide(color: Colors.grey.shade300)),
                                  ),
                                  child: const Row(
                                    children: [
                                      Icon(Icons.list, size: 16),
                                      SizedBox(width: 8),
                                      Text(
                                        'Liste des achats',
                                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                                      ),
                                    ],
                                  ),
                                ),
                                Container(
                                  padding: const EdgeInsets.all(8),
                                  decoration: BoxDecoration(
                                    border: Border(bottom: BorderSide(color: Colors.grey.shade300)),
                                  ),
                                  child: TextField(
                                    controller: _searchAchatsController,
                                    focusNode: _searchAchatsFocusNode,
                                    decoration: const InputDecoration(
                                      hintText: 'Rechercher... (Ctrl+F)',
                                      prefixIcon: Icon(Icons.search, size: 16),
                                      border: OutlineInputBorder(),
                                      contentPadding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                    ),
                                    style: const TextStyle(fontSize: 11),
                                    onChanged: (value) {
                                      setState(() {
                                        _searchAchatsText = value.toLowerCase();
                                      });
                                    },
                                  ),
                                ),
                                Expanded(
                                  child: _achatsNumbers.isEmpty
                                      ? const Center(
                                          child: Text('Aucun achat', style: TextStyle(fontSize: 11)),
                                        )
                                      : Column(
                                          children: [
                                            // Section Brouillard
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                              decoration: BoxDecoration(
                                                color: Colors.orange.shade50,
                                                border: Border(
                                                  bottom: BorderSide(color: Colors.grey.shade300),
                                                ),
                                              ),
                                              child: Row(
                                                children: [
                                                  Icon(
                                                    Icons.edit_note,
                                                    size: 14,
                                                    color: Colors.orange.shade700,
                                                  ),
                                                  const SizedBox(width: 4),
                                                  Text(
                                                    'Brouillard',
                                                    style: TextStyle(
                                                      fontSize: 11,
                                                      fontWeight: FontWeight.bold,
                                                      color: Colors.orange.shade700,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Expanded(
                                              flex: 1,
                                              child: ListView.builder(
                                                itemCount: _getBrouillardAchats().length,
                                                itemBuilder: (context, index) {
                                                  final numAchat = _getBrouillardAchats()[index];
                                                  return Container(
                                                    decoration: BoxDecoration(
                                                      color: _numAchatsController.text == numAchat
                                                          ? Colors.orange.shade100
                                                          : null,
                                                      border: Border(
                                                        bottom: BorderSide(
                                                          color: Colors.grey.shade200,
                                                          width: 0.5,
                                                        ),
                                                      ),
                                                    ),
                                                    child: ListTile(
                                                      dense: true,
                                                      contentPadding: const EdgeInsets.symmetric(
                                                        horizontal: 8,
                                                        vertical: 0,
                                                      ),
                                                      title: Text(
                                                        'N° $numAchat',
                                                        style: const TextStyle(fontSize: 11),
                                                      ),
                                                      onTap: () => _chargerAchatExistant(numAchat),
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                            // Section Journal
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                              decoration: BoxDecoration(
                                                color: Colors.green.shade50,
                                                border: Border(
                                                  bottom: BorderSide(color: Colors.grey.shade300),
                                                ),
                                              ),
                                              child: Row(
                                                children: [
                                                  Icon(
                                                    Icons.check_circle,
                                                    size: 14,
                                                    color: Colors.green.shade700,
                                                  ),
                                                  const SizedBox(width: 4),
                                                  Text(
                                                    'Journal (Ctrl + L)',
                                                    style: TextStyle(
                                                      fontSize: 11,
                                                      fontWeight: FontWeight.bold,
                                                      color: Colors.green.shade700,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Expanded(
                                              flex: 1,
                                              child: ListView.builder(
                                                itemCount: _getJournalAchats().length,
                                                itemBuilder: (context, index) {
                                                  final numAchat = _getJournalAchats()[index];
                                                  return Container(
                                                    decoration: BoxDecoration(
                                                      color: _numAchatsController.text == numAchat
                                                          ? Colors.green.shade100
                                                          : null,
                                                      border: Border(
                                                        bottom: BorderSide(
                                                          color: Colors.grey.shade200,
                                                          width: 0.5,
                                                        ),
                                                      ),
                                                    ),
                                                    child: ListTile(
                                                      dense: true,
                                                      contentPadding: const EdgeInsets.symmetric(
                                                        horizontal: 8,
                                                        vertical: 0,
                                                      ),
                                                      title: Text(
                                                        'N° $numAchat',
                                                        style: const TextStyle(fontSize: 11),
                                                      ),
                                                      onTap: () => _chargerAchatExistant(numAchat),
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                            // Section Contre-passé
                                            Container(
                                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                              decoration: BoxDecoration(
                                                color: Colors.red.shade50,
                                                border: Border(
                                                  bottom: BorderSide(color: Colors.grey.shade300),
                                                ),
                                              ),
                                              child: Row(
                                                children: [
                                                  Icon(Icons.block, size: 14, color: Colors.red.shade700),
                                                  const SizedBox(width: 4),
                                                  Text(
                                                    'Contre-passé',
                                                    style: TextStyle(
                                                      fontSize: 11,
                                                      fontWeight: FontWeight.bold,
                                                      color: Colors.red.shade700,
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ),
                                            Expanded(
                                              flex: 1,
                                              child: ListView.builder(
                                                itemCount: _getContrePasseAchats().length,
                                                itemBuilder: (context, index) {
                                                  final numAchat = _getContrePasseAchats()[index];
                                                  return Container(
                                                    decoration: BoxDecoration(
                                                      color: _numAchatsController.text == numAchat
                                                          ? Colors.red.shade100
                                                          : null,
                                                      border: Border(
                                                        bottom: BorderSide(
                                                          color: Colors.grey.shade200,
                                                          width: 0.5,
                                                        ),
                                                      ),
                                                    ),
                                                    child: ListTile(
                                                      dense: true,
                                                      contentPadding: const EdgeInsets.symmetric(
                                                        horizontal: 8,
                                                        vertical: 0,
                                                      ),
                                                      title: Text(
                                                        'N° $numAchat',
                                                        style: const TextStyle(fontSize: 11),
                                                      ),
                                                      onTap: () => _chargerAchatExistant(numAchat),
                                                    ),
                                                  );
                                                },
                                              ),
                                            ),
                                          ],
                                        ),
                                ),
                              ],
                            ),
                          ),
                          // Formulaire principal à  droite
                          Expanded(
                            child: FocusTraversalGroup(
                              policy: OrderedTraversalPolicy(),
                              child: Column(
                                children: [
                                  // Title bar with close button
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 8),
                                    height: 35,
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child: Padding(
                                            padding: const EdgeInsets.only(left: 16),
                                            child: Row(
                                              children: [
                                                const Text(
                                                  'Achat fournisseurs',
                                                  style: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
                                                ),
                                                if (_isExistingPurchase && _statutAchatActuel != null) ...[
                                                  const SizedBox(width: 8),
                                                  Container(
                                                    padding: const EdgeInsets.symmetric(
                                                      horizontal: 6,
                                                      vertical: 2,
                                                    ),
                                                    decoration: BoxDecoration(
                                                      color: _statutAchatActuel == 'JOURNAL'
                                                          ? Colors.green
                                                          : _statutAchatActuel == 'CONTRE-PASSé'
                                                          ? Colors.red
                                                          : Colors.orange,
                                                      borderRadius: BorderRadius.circular(8),
                                                    ),
                                                    child: Text(
                                                      _statutAchatActuel == 'JOURNAL'
                                                          ? 'J'
                                                          : _statutAchatActuel == 'CONTRE-PASSé'
                                                          ? 'CP'
                                                          : 'B',
                                                      style: const TextStyle(
                                                        color: Colors.white,
                                                        fontSize: 10,
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ],
                                            ),
                                          ),
                                        ),
                                        ExcludeFocus(
                                          child: IconButton(
                                            onPressed: () => Navigator.of(context).pop(),
                                            icon: const Icon(Icons.close, size: 20),
                                            padding: EdgeInsets.zero,
                                            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  // Top section with form fields
                                  Container(
                                    color: const Color(0xFFE6E6FA),
                                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                                    child: Row(
                                      children: [
                                        // Left side with Enregistrement button and Journal dropdown
                                        ExcludeFocus(
                                          child: Column(
                                            children: [
                                              Container(
                                                width: 120,
                                                padding: const EdgeInsets.symmetric(
                                                  horizontal: 8,
                                                  vertical: 1,
                                                ),
                                                color: Colors.green,
                                                child: const Text(
                                                  'Enregistrement',
                                                  style: TextStyle(color: Colors.white, fontSize: 12),
                                                ),
                                              ),
                                              const SizedBox(height: 2),
                                              SizedBox(
                                                width: 120,
                                                height: 25,
                                                child: DropdownButtonFormField<String>(
                                                  initialValue: _selectedStatut,
                                                  decoration: InputDecoration(
                                                    border: const OutlineInputBorder(),
                                                    contentPadding: const EdgeInsets.symmetric(
                                                      horizontal: 4,
                                                      vertical: 2,
                                                    ),
                                                    fillColor: _selectedStatut == 'Journal'
                                                        ? Colors.green.shade100
                                                        : Colors.orange.shade100,
                                                    filled: true,
                                                  ),
                                                  items: const [
                                                    DropdownMenuItem(
                                                      value: 'Journal',
                                                      child: Text('Journal', style: TextStyle(fontSize: 12)),
                                                    ),
                                                    DropdownMenuItem(
                                                      value: 'Brouillard',
                                                      child: Text(
                                                        'Brouillard',
                                                        style: TextStyle(fontSize: 12),
                                                      ),
                                                    ),
                                                  ],
                                                  onChanged: _isExistingPurchase
                                                      ? null
                                                      : (value) {
                                                          setState(() {
                                                            _selectedStatut = value ?? 'Brouillard';
                                                          });
                                                        },
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(width: 32),
                                        // Form fields
                                        Expanded(
                                          child: Column(
                                            children: [
                                              // First row: N°Achats, Date et N° Facture
                                              Row(
                                                children: [
                                                  const ExcludeFocus(
                                                    child: Text('N° Achats', style: TextStyle(fontSize: 12)),
                                                  ),
                                                  const SizedBox(width: 4),
                                                  SizedBox(
                                                    width: 100,
                                                    height: 25,
                                                    child: ExcludeFocus(
                                                      child: TextField(
                                                        textAlign: TextAlign.center,
                                                        controller: _numAchatsController,
                                                        readOnly: true,
                                                        decoration: const InputDecoration(
                                                          border: OutlineInputBorder(),
                                                          contentPadding: EdgeInsets.symmetric(
                                                            horizontal: 4,
                                                            vertical: 2,
                                                          ),
                                                          fillColor: Color(0xFFF5F5F5),
                                                          filled: true,
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                  const Expanded(child: SizedBox()),
                                                  const ExcludeFocus(
                                                    child: Text('Date', style: TextStyle(fontSize: 12)),
                                                  ),
                                                  const SizedBox(width: 4),
                                                  SizedBox(
                                                    width: 140,
                                                    height: 25,
                                                    child: ExcludeFocus(
                                                      child: TextField(
                                                        controller: _dateController,
                                                        readOnly: true,
                                                        decoration: const InputDecoration(
                                                          border: OutlineInputBorder(),
                                                          contentPadding: EdgeInsets.symmetric(
                                                            horizontal: 4,
                                                            vertical: 2,
                                                          ),
                                                          suffixIcon: Icon(Icons.calendar_today, size: 16),
                                                        ),
                                                        onTap: () async {
                                                          final date = await showDatePicker(
                                                            context: context,
                                                            initialDate: DateTime.now(),
                                                            firstDate: DateTime(2000),
                                                            lastDate: DateTime(2100),
                                                          );
                                                          if (date != null) {
                                                            _dateController.text =
                                                                app_date.AppDateUtils.formatDate(date);
                                                          }
                                                        },
                                                      ),
                                                    ),
                                                  ),
                                                  const SizedBox(width: 8),
                                                  const ExcludeFocus(
                                                    child: Text(
                                                      'N° Facture/ BL',
                                                      style: TextStyle(fontSize: 12),
                                                    ),
                                                  ),
                                                  const SizedBox(width: 4),
                                                  Flexible(
                                                    child: SizedBox(
                                                      width: 150,
                                                      height: 25,
                                                      child: Focus(
                                                        onKeyEvent: (node, event) {
                                                          if (event is KeyDownEvent &&
                                                              event.logicalKey == LogicalKeyboardKey.tab) {
                                                            _fournisseurFocusNode.requestFocus();
                                                            return KeyEventResult.handled;
                                                          }
                                                          return KeyEventResult.ignored;
                                                        },
                                                        child: TextField(
                                                          textAlign: TextAlign.center,
                                                          controller: _nFactController,
                                                          focusNode: _nFactFocusNode,
                                                          enabled: _statutAchatActuel != 'JOURNAL',
                                                          onSubmitted: (_) =>
                                                              _fournisseurFocusNode.requestFocus(),
                                                          decoration: InputDecoration(
                                                            border: const OutlineInputBorder(),
                                                            contentPadding: const EdgeInsets.symmetric(
                                                              horizontal: 4,
                                                              vertical: 2,
                                                            ),
                                                            fillColor: _statutAchatActuel == 'JOURNAL'
                                                                ? Colors.grey.shade200
                                                                : null,
                                                            filled: _statutAchatActuel == 'JOURNAL',
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              const SizedBox(height: 8),
                                              // Second row: Label et champ Formulaire
                                              Row(
                                                children: [
                                                  const ExcludeFocus(
                                                    child: Text(
                                                      'Fournisseurs',
                                                      style: TextStyle(fontSize: 12),
                                                    ),
                                                  ),
                                                  const SizedBox(width: 8),
                                                  Expanded(
                                                    child: SizedBox(
                                                      height: 30,
                                                      child: Row(
                                                        children: [
                                                          Expanded(
                                                            child: Focus(
                                                              onFocusChange: (hasFocus) {
                                                                if (!hasFocus &&
                                                                    _fournisseurController.text.isNotEmpty) {
                                                                  _verifierEtCreerFournisseur(
                                                                    _fournisseurController.text,
                                                                  );
                                                                }
                                                              },
                                                              onKeyEvent: (node, event) {
                                                                if (event is KeyDownEvent &&
                                                                    event.logicalKey ==
                                                                        LogicalKeyboardKey.tab) {
                                                                  final isShiftPressed =
                                                                      HardwareKeyboard
                                                                          .instance
                                                                          .logicalKeysPressed
                                                                          .contains(
                                                                            LogicalKeyboardKey.shiftLeft,
                                                                          ) ||
                                                                      HardwareKeyboard
                                                                          .instance
                                                                          .logicalKeysPressed
                                                                          .contains(
                                                                            LogicalKeyboardKey.shiftRight,
                                                                          );

                                                                  if (isShiftPressed) {
                                                                    _nFactFocusNode.requestFocus();
                                                                  } else {
                                                                    _articleFocusNode.requestFocus();
                                                                  }
                                                                  return KeyEventResult.handled;
                                                                }
                                                                return KeyEventResult.ignored;
                                                              },
                                                              child: EnhancedAutocomplete<Frn>(
                                                                controller: _fournisseurController,
                                                                focusNode: _fournisseurFocusNode,
                                                                options: _fournisseurs,
                                                                displayStringForOption: (frn) => frn.rsoc,
                                                                onSelected: (frn) {
                                                                  if (_statutAchatActuel != 'JOURNAL') {
                                                                    setState(() {
                                                                      _selectedFournisseur = frn.rsoc;
                                                                    });
                                                                    _articleFocusNode.requestFocus();
                                                                  }
                                                                },
                                                                onFieldSubmitted: (_) =>
                                                                    _articleFocusNode.requestFocus(),
                                                                hintText:
                                                                    'Rechercher fournisseur... (â† â†’ pour naviguer)',
                                                                decoration: InputDecoration(
                                                                  border: const OutlineInputBorder(),
                                                                  contentPadding: const EdgeInsets.symmetric(
                                                                    horizontal: 4,
                                                                    vertical: 2,
                                                                  ),
                                                                  fillColor: _statutAchatActuel == 'JOURNAL'
                                                                      ? Colors.grey.shade200
                                                                      : null,
                                                                  filled: _statutAchatActuel == 'JOURNAL',
                                                                ),
                                                                style: const TextStyle(fontSize: 12),
                                                              ),
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),

                                  // Article selection section
                                  Container(
                                    color: const Color(0xFFE6E6FA),
                                    padding: const EdgeInsets.all(8),
                                    child: Row(
                                      children: [
                                        // Désignation Articles column
                                        Expanded(
                                          flex: 3,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              const Text(
                                                'Désignation Articles',
                                                style: TextStyle(fontSize: 12),
                                              ),
                                              const SizedBox(height: 4),
                                              SizedBox(
                                                height: 30,
                                                child: ArticleNavigationAutocomplete(
                                                  articles: _articles,
                                                  initialArticle: _lignesAchat.isNotEmpty
                                                      ? _articles
                                                            .where(
                                                              (a) =>
                                                                  a.designation ==
                                                                  _lignesAchat.last['designation'],
                                                            )
                                                            .firstOrNull
                                                      : null,
                                                  selectedArticle:
                                                      _selectedArticle, // Ajouter la synchronisation
                                                  onArticleChanged: _onArticleSelected,
                                                  focusNode: _articleFocusNode,
                                                  enabled: _statutAchatActuel != 'JOURNAL',
                                                  hintText: 'Rechercher article... (â† â†’ pour naviguer)',
                                                  decoration: InputDecoration(
                                                    border: const OutlineInputBorder(),
                                                    contentPadding: const EdgeInsets.symmetric(
                                                      horizontal: 4,
                                                      vertical: 2,
                                                    ),
                                                    fillColor: _statutAchatActuel == 'JOURNAL'
                                                        ? Colors.grey.shade200
                                                        : null,
                                                    filled: _statutAchatActuel == 'JOURNAL',
                                                  ),
                                                  style: const TextStyle(fontSize: 12),
                                                  onTabPressed: () => _uniteFocusNode.requestFocus(),
                                                  onShiftTabPressed: () =>
                                                      _fournisseurFocusNode.requestFocus(),
                                                ),
                                              ),
                                              // Affichage des unités disponibles et stock
                                              if (_selectedArticle == null) ...[const SizedBox(height: 19)],
                                              if (_selectedArticle != null) ...[
                                                const SizedBox(height: 2),
                                                if (_selectedDepot != null)
                                                  FutureBuilder<String>(
                                                    future: _getStocksToutesUnites(
                                                      _selectedArticle!,
                                                      _selectedDepot!,
                                                    ),
                                                    builder: (context, snapshot) {
                                                      if (snapshot.hasData && snapshot.data!.isNotEmpty) {
                                                        return Text(
                                                          'Stock: ${snapshot.data}',
                                                          style: TextStyle(
                                                            fontSize: 11,
                                                            color: Colors.green.shade700,
                                                            fontWeight: FontWeight.w500,
                                                          ),
                                                        );
                                                      }
                                                      return const SizedBox.shrink();
                                                    },
                                                  ),
                                              ],
                                            ],
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        // Unités column
                                        Expanded(
                                          flex: 1,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              const Text('Unités', style: TextStyle(fontSize: 12)),
                                              const SizedBox(height: 4),
                                              SizedBox(
                                                height: 30,
                                                child: Row(
                                                  children: [
                                                    Expanded(
                                                      child: Focus(
                                                        onFocusChange: (hasFocus) {
                                                          if (!hasFocus &&
                                                              _uniteController.text.isNotEmpty &&
                                                              _selectedArticle != null &&
                                                              _statutAchatActuel != 'JOURNAL') {
                                                            _verifierUniteArticle(_uniteController.text);
                                                          }
                                                        },
                                                        onKeyEvent: (node, event) {
                                                          if (event is KeyDownEvent &&
                                                              event.logicalKey == LogicalKeyboardKey.tab) {
                                                            final isShiftPressed =
                                                                HardwareKeyboard.instance.logicalKeysPressed
                                                                    .contains(LogicalKeyboardKey.shiftLeft) ||
                                                                HardwareKeyboard.instance.logicalKeysPressed
                                                                    .contains(LogicalKeyboardKey.shiftRight);

                                                            if (isShiftPressed) {
                                                              _articleFocusNode.requestFocus();
                                                            } else {
                                                              _quantiteFocusNode.requestFocus();
                                                            }
                                                            return KeyEventResult.handled;
                                                          }
                                                          return KeyEventResult.ignored;
                                                        },
                                                        child: EnhancedAutocomplete<String>(
                                                          controller: _uniteController,
                                                          focusNode: _uniteFocusNode,
                                                          enabled:
                                                              _selectedArticle != null &&
                                                              _statutAchatActuel != 'JOURNAL',
                                                          options: _getUnitsForSelectedArticle()
                                                              .map((item) => item.value!)
                                                              .toList(),
                                                          displayStringForOption: (unite) => unite,
                                                          onSelected: (unite) {
                                                            if (_selectedArticle != null &&
                                                                _statutAchatActuel != 'JOURNAL') {
                                                              _verifierUniteArticle(unite);
                                                              _quantiteFocusNode.requestFocus();
                                                            }
                                                          },
                                                          onTabPressed: () =>
                                                              _quantiteFocusNode.requestFocus(),
                                                          onShiftTabPressed: () =>
                                                              _articleFocusNode.requestFocus(),
                                                          onFieldSubmitted: (_) =>
                                                              _quantiteFocusNode.requestFocus(),
                                                          hintText: 'Unité...',
                                                          decoration: InputDecoration(
                                                            border: const OutlineInputBorder(),
                                                            contentPadding: const EdgeInsets.symmetric(
                                                              horizontal: 4,
                                                              vertical: 2,
                                                            ),
                                                            fillColor:
                                                                _selectedArticle == null ||
                                                                    _statutAchatActuel == 'JOURNAL'
                                                                ? Colors.grey.shade200
                                                                : null,
                                                            filled:
                                                                _selectedArticle == null ||
                                                                _statutAchatActuel == 'JOURNAL',
                                                          ),
                                                          style: const TextStyle(fontSize: 12),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              const SizedBox(height: 19),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        // Quantités column
                                        Expanded(
                                          flex: 1,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              const Text('Quantités', style: TextStyle(fontSize: 12)),
                                              const SizedBox(height: 4),
                                              SizedBox(
                                                height: 30,
                                                child: Focus(
                                                  onKeyEvent: (node, event) {
                                                    if (event is KeyDownEvent &&
                                                        event.logicalKey == LogicalKeyboardKey.tab) {
                                                      final isShiftPressed =
                                                          HardwareKeyboard.instance.logicalKeysPressed
                                                              .contains(LogicalKeyboardKey.shiftLeft) ||
                                                          HardwareKeyboard.instance.logicalKeysPressed
                                                              .contains(LogicalKeyboardKey.shiftRight);

                                                      if (isShiftPressed) {
                                                        _uniteFocusNode.requestFocus();
                                                      } else {
                                                        _prixFocusNode.requestFocus();
                                                      }
                                                      return KeyEventResult.handled;
                                                    }
                                                    return KeyEventResult.ignored;
                                                  },
                                                  child: TextField(
                                                    controller: _quantiteController,
                                                    focusNode: _quantiteFocusNode,
                                                    readOnly:
                                                        _selectedArticle == null ||
                                                        _statutAchatActuel == 'JOURNAL',
                                                    onSubmitted: (_) => _prixFocusNode.requestFocus(),
                                                    keyboardType: TextInputType.number,
                                                    inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                                                    decoration: InputDecoration(
                                                      border: const OutlineInputBorder(),
                                                      contentPadding: const EdgeInsets.symmetric(
                                                        horizontal: 4,
                                                        vertical: 2,
                                                      ),
                                                      fillColor:
                                                          _selectedArticle == null ||
                                                              _statutAchatActuel == 'JOURNAL'
                                                          ? Colors.grey.shade200
                                                          : null,
                                                      filled:
                                                          _selectedArticle == null ||
                                                          _statutAchatActuel == 'JOURNAL',
                                                    ),
                                                    style: const TextStyle(fontSize: 12),
                                                    onChanged: (value) {
                                                      setState(() {});
                                                    },
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(height: 19),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        // P.U HT column
                                        Expanded(
                                          flex: 1,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              const Text('P.U HT', style: TextStyle(fontSize: 12)),
                                              const SizedBox(height: 4),
                                              SizedBox(
                                                height: 30,
                                                child: Focus(
                                                  onKeyEvent: (node, event) {
                                                    if (event is KeyDownEvent &&
                                                        event.logicalKey == LogicalKeyboardKey.tab) {
                                                      final isShiftPressed =
                                                          HardwareKeyboard.instance.logicalKeysPressed
                                                              .contains(LogicalKeyboardKey.shiftLeft) ||
                                                          HardwareKeyboard.instance.logicalKeysPressed
                                                              .contains(LogicalKeyboardKey.shiftRight);

                                                      if (isShiftPressed) {
                                                        _quantiteFocusNode.requestFocus();
                                                      } else {
                                                        _depotFocusNode.requestFocus();
                                                      }
                                                      return KeyEventResult.handled;
                                                    }
                                                    return KeyEventResult.ignored;
                                                  },
                                                  child: TextField(
                                                    controller: _prixController,
                                                    focusNode: _prixFocusNode,
                                                    readOnly:
                                                        _selectedArticle == null ||
                                                        _statutAchatActuel == 'JOURNAL',
                                                    onSubmitted: (_) => _depotFocusNode.requestFocus(),
                                                    decoration: InputDecoration(
                                                      border: const OutlineInputBorder(),
                                                      contentPadding: const EdgeInsets.symmetric(
                                                        horizontal: 4,
                                                        vertical: 2,
                                                      ),
                                                      fillColor:
                                                          _selectedArticle == null ||
                                                              _statutAchatActuel == 'JOURNAL'
                                                          ? Colors.grey.shade200
                                                          : null,
                                                      filled:
                                                          _selectedArticle == null ||
                                                          _statutAchatActuel == 'JOURNAL',
                                                    ),
                                                    style: const TextStyle(fontSize: 12),
                                                  ),
                                                ),
                                              ),
                                              const SizedBox(height: 19),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(width: 8),
                                        // Dépôts column
                                        Expanded(
                                          flex: 1,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              const Text('Dépôts', style: TextStyle(fontSize: 12)),
                                              const SizedBox(height: 4),
                                              SizedBox(
                                                height: 30,
                                                child: Row(
                                                  children: [
                                                    Expanded(
                                                      child: Focus(
                                                        onKeyEvent: (node, event) {
                                                          if (event is KeyDownEvent &&
                                                              event.logicalKey == LogicalKeyboardKey.tab) {
                                                            final isShiftPressed =
                                                                HardwareKeyboard.instance.logicalKeysPressed
                                                                    .contains(LogicalKeyboardKey.shiftLeft) ||
                                                                HardwareKeyboard.instance.logicalKeysPressed
                                                                    .contains(LogicalKeyboardKey.shiftRight);

                                                            if (isShiftPressed) {
                                                              _prixFocusNode.requestFocus();
                                                            } else {
                                                              if (_isArticleFormValid() &&
                                                                  _statutAchatActuel != 'JOURNAL') {
                                                                _validerFocusNode.requestFocus();
                                                              } else {
                                                                _nFactFocusNode.requestFocus();
                                                              }
                                                            }
                                                            return KeyEventResult.handled;
                                                          }
                                                          return KeyEventResult.ignored;
                                                        },
                                                        child: EnhancedAutocomplete<String>(
                                                          controller: _depotController,
                                                          focusNode: _depotFocusNode,
                                                          options: _depots,
                                                          displayStringForOption: (depot) => depot,
                                                          onSelected: (depot) {
                                                            if (_statutAchatActuel != 'JOURNAL') {
                                                              setState(() {
                                                                _selectedDepot = depot;
                                                              });
                                                              if (_isArticleFormValid()) {
                                                                _validerFocusNode.requestFocus();
                                                              } else {
                                                                _nFactFocusNode.requestFocus();
                                                              }
                                                            }
                                                          },
                                                          onTabPressed: () {
                                                            if (_isArticleFormValid() &&
                                                                _statutAchatActuel != 'JOURNAL') {
                                                              _validerFocusNode.requestFocus();
                                                            } else {
                                                              _nFactFocusNode.requestFocus();
                                                            }
                                                          },
                                                          onShiftTabPressed: () =>
                                                              _prixFocusNode.requestFocus(),
                                                          onSubmitted: (_) {
                                                            if (_isArticleFormValid() &&
                                                                _statutAchatActuel != 'JOURNAL') {
                                                              _validerFocusNode.requestFocus();
                                                            } else {
                                                              _nFactFocusNode.requestFocus();
                                                            }
                                                          },
                                                          hintText: 'Dépôt...',
                                                          decoration: InputDecoration(
                                                            border: const OutlineInputBorder(),
                                                            contentPadding: const EdgeInsets.symmetric(
                                                              horizontal: 4,
                                                              vertical: 2,
                                                            ),
                                                            fillColor: _statutAchatActuel == 'JOURNAL'
                                                                ? Colors.grey.shade200
                                                                : null,
                                                            filled: _statutAchatActuel == 'JOURNAL',
                                                          ),
                                                          style: const TextStyle(fontSize: 12),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              const SizedBox(height: 19),
                                            ],
                                          ),
                                        ),

                                        //Bouton valider et  Annuler
                                        if (_isArticleFormValid() && _statutAchatActuel != 'JOURNAL') ...[
                                          const SizedBox(width: 8),
                                          Column(
                                            children: [
                                              const SizedBox(height: 16),
                                              Row(
                                                children: [
                                                  //Bouton Ajouter lignes
                                                  Column(
                                                    children: [
                                                      Focus(
                                                        focusNode: _validerFocusNode,
                                                        onKeyEvent: (node, event) {
                                                          if (event is KeyDownEvent) {
                                                            if (event.logicalKey == LogicalKeyboardKey.tab) {
                                                              final isShiftPressed =
                                                                  HardwareKeyboard.instance.logicalKeysPressed
                                                                      .contains(
                                                                        LogicalKeyboardKey.shiftLeft,
                                                                      ) ||
                                                                  HardwareKeyboard.instance.logicalKeysPressed
                                                                      .contains(
                                                                        LogicalKeyboardKey.shiftRight,
                                                                      );

                                                              if (isShiftPressed) {
                                                                _depotFocusNode.requestFocus();
                                                              } else {
                                                                _annulerFocusNode.requestFocus();
                                                              }
                                                              return KeyEventResult.handled;
                                                            } else if (event.logicalKey ==
                                                                LogicalKeyboardKey.enter) {
                                                              if (_validerFocusNode.hasFocus) {
                                                                _validerAjout();
                                                              }
                                                              return KeyEventResult.handled;
                                                            }
                                                          }
                                                          return KeyEventResult.ignored;
                                                        },
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            border: _validerFocusNode.hasFocus
                                                                ? Border.all(color: Colors.blue, width: 3)
                                                                : null,
                                                            borderRadius: BorderRadius.circular(4),
                                                            boxShadow: _validerFocusNode.hasFocus
                                                                ? [
                                                                    BoxShadow(
                                                                      color: Colors.blue.withValues(
                                                                        alpha: 0.3,
                                                                      ),
                                                                      blurRadius: 4,
                                                                      spreadRadius: 1,
                                                                    ),
                                                                  ]
                                                                : null,
                                                          ),
                                                          child: ElevatedButton(
                                                            onPressed: _validerAjout,
                                                            style: ElevatedButton.styleFrom(
                                                              backgroundColor: _validerFocusNode.hasFocus
                                                                  ? Colors.green[600]
                                                                  : Colors.green,
                                                              foregroundColor: Colors.white,
                                                              minimumSize: const Size(60, 35),
                                                              elevation: _validerFocusNode.hasFocus ? 4 : 2,
                                                            ),
                                                            child: Text(
                                                              _validerFocusNode.hasFocus
                                                                  ? 'Ajouter ↵'
                                                                  : 'Ajouter',
                                                              style: TextStyle(
                                                                fontSize: 12,
                                                                fontWeight: _validerFocusNode.hasFocus
                                                                    ? FontWeight.bold
                                                                    : FontWeight.normal,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      const SizedBox(height: 16),
                                                    ],
                                                  ),
                                                  const SizedBox(width: 4),
                                                  // Bouton annuler
                                                  Column(
                                                    children: [
                                                      Focus(
                                                        focusNode: _annulerFocusNode,
                                                        onKeyEvent: (node, event) {
                                                          if (event is KeyDownEvent) {
                                                            if (event.logicalKey == LogicalKeyboardKey.tab) {
                                                              final isShiftPressed =
                                                                  HardwareKeyboard.instance.logicalKeysPressed
                                                                      .contains(
                                                                        LogicalKeyboardKey.shiftLeft,
                                                                      ) ||
                                                                  HardwareKeyboard.instance.logicalKeysPressed
                                                                      .contains(
                                                                        LogicalKeyboardKey.shiftRight,
                                                                      );

                                                              if (isShiftPressed) {
                                                                _validerFocusNode.requestFocus();
                                                              } else {
                                                                _nFactFocusNode.requestFocus();
                                                              }
                                                              return KeyEventResult.handled;
                                                            } else if (event.logicalKey ==
                                                                LogicalKeyboardKey.enter) {
                                                              if (_annulerFocusNode.hasFocus) {
                                                                _resetArticleForm();
                                                              }
                                                              return KeyEventResult.handled;
                                                            }
                                                          }
                                                          return KeyEventResult.ignored;
                                                        },
                                                        child: Container(
                                                          decoration: BoxDecoration(
                                                            border: _annulerFocusNode.hasFocus
                                                                ? Border.all(color: Colors.blue, width: 3)
                                                                : null,
                                                            borderRadius: BorderRadius.circular(4),
                                                            boxShadow: _annulerFocusNode.hasFocus
                                                                ? [
                                                                    BoxShadow(
                                                                      color: Colors.blue.withValues(
                                                                        alpha: 0.3,
                                                                      ),
                                                                      blurRadius: 4,
                                                                      spreadRadius: 1,
                                                                    ),
                                                                  ]
                                                                : null,
                                                          ),
                                                          child: ElevatedButton(
                                                            onPressed: _resetArticleForm,
                                                            style: ElevatedButton.styleFrom(
                                                              backgroundColor: _annulerFocusNode.hasFocus
                                                                  ? Colors.orange[600]
                                                                  : Colors.orange,
                                                              foregroundColor: Colors.white,
                                                              minimumSize: const Size(60, 35),
                                                              elevation: _annulerFocusNode.hasFocus ? 4 : 2,
                                                            ),
                                                            child: Text(
                                                              _annulerFocusNode.hasFocus
                                                                  ? 'Annuler ↵'
                                                                  : 'Annuler',
                                                              style: TextStyle(
                                                                fontSize: 12,
                                                                fontWeight: _annulerFocusNode.hasFocus
                                                                    ? FontWeight.bold
                                                                    : FontWeight.normal,
                                                              ),
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                      const SizedBox(height: 16),
                                                    ],
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ],
                                      ],
                                    ),
                                  ),

                                  // Articles table
                                  Expanded(
                                    child: Container(
                                      margin: const EdgeInsets.all(8),
                                      decoration: BoxDecoration(
                                        border: Border.all(color: Colors.grey, width: 1),
                                        color: Colors.white,
                                      ),
                                      child: Column(
                                        children: [
                                          // Table header
                                          Container(
                                            height: 25,
                                            decoration: BoxDecoration(color: Colors.orange[300]),
                                            child: Row(
                                              children: [
                                                Container(
                                                  width: 50,
                                                  alignment: Alignment.center,
                                                  decoration: const BoxDecoration(
                                                    border: Border(
                                                      right: BorderSide(color: Colors.grey, width: 1),
                                                      bottom: BorderSide(color: Colors.grey, width: 1),
                                                    ),
                                                  ),
                                                  child: const Text(
                                                    'ACTION',
                                                    style: TextStyle(
                                                      fontSize: 11,
                                                      fontWeight: FontWeight.bold,
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 3,
                                                  child: Container(
                                                    alignment: Alignment.center,
                                                    decoration: const BoxDecoration(
                                                      border: Border(
                                                        right: BorderSide(color: Colors.grey, width: 1),
                                                        bottom: BorderSide(color: Colors.grey, width: 1),
                                                      ),
                                                    ),
                                                    child: const Text(
                                                      'DESIGNATION',
                                                      style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 1,
                                                  child: Container(
                                                    alignment: Alignment.center,
                                                    decoration: const BoxDecoration(
                                                      border: Border(
                                                        right: BorderSide(color: Colors.grey, width: 1),
                                                        bottom: BorderSide(color: Colors.grey, width: 1),
                                                      ),
                                                    ),
                                                    child: const Text(
                                                      'UNITE',
                                                      style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 1,
                                                  child: Container(
                                                    alignment: Alignment.center,
                                                    decoration: const BoxDecoration(
                                                      border: Border(
                                                        right: BorderSide(color: Colors.grey, width: 1),
                                                        bottom: BorderSide(color: Colors.grey, width: 1),
                                                      ),
                                                    ),
                                                    child: const Text(
                                                      'QUANTITE',
                                                      style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 2,
                                                  child: Container(
                                                    alignment: Alignment.center,
                                                    decoration: const BoxDecoration(
                                                      border: Border(
                                                        right: BorderSide(color: Colors.grey, width: 1),
                                                        bottom: BorderSide(color: Colors.grey, width: 1),
                                                      ),
                                                    ),
                                                    child: const Text(
                                                      'PRIX UNITAIRE',
                                                      style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 2,
                                                  child: Container(
                                                    alignment: Alignment.center,
                                                    decoration: const BoxDecoration(
                                                      border: Border(
                                                        right: BorderSide(color: Colors.grey, width: 1),
                                                        bottom: BorderSide(color: Colors.grey, width: 1),
                                                      ),
                                                    ),
                                                    child: const Text(
                                                      'MONTANT',
                                                      style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                                Expanded(
                                                  flex: 1,
                                                  child: Container(
                                                    alignment: Alignment.center,
                                                    decoration: const BoxDecoration(
                                                      border: Border(
                                                        bottom: BorderSide(color: Colors.grey, width: 1),
                                                      ),
                                                    ),
                                                    child: const Text(
                                                      'DEPOT',
                                                      style: TextStyle(
                                                        fontSize: 11,
                                                        fontWeight: FontWeight.bold,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          // Table content
                                          Expanded(
                                            child: _lignesAchat.isEmpty
                                                ? const Center(
                                                    child: Text(
                                                      'Aucun article ajouté',
                                                      style: TextStyle(
                                                        fontSize: 14,
                                                        color: Colors.grey,
                                                        fontStyle: FontStyle.italic,
                                                      ),
                                                    ),
                                                  )
                                                : ListView.builder(
                                                    itemCount: _lignesAchat.length,
                                                    itemExtent: 18,
                                                    itemBuilder: (context, index) {
                                                      final ligne = _lignesAchat[index];
                                                      return MouseRegion(
                                                        onEnter: (_) {
                                                          setState(() {
                                                            _selectedRowIndex = index;
                                                          });
                                                        },
                                                        onExit: (_) {
                                                          setState(() {
                                                            _selectedRowIndex = index;
                                                          });
                                                        },
                                                        child: GestureDetector(
                                                          onTap: () {
                                                            setState(() {
                                                              _selectedRowIndex = index;
                                                            });
                                                          },
                                                          onSecondaryTapUp: _statutAchatActuel == 'JOURNAL'
                                                              ? null
                                                              : (details) {
                                                                  showMenu(
                                                                    context: context,
                                                                    position: RelativeRect.fromLTRB(
                                                                      details.globalPosition.dx,
                                                                      details.globalPosition.dy,
                                                                      details.globalPosition.dx,
                                                                      details.globalPosition.dy,
                                                                    ),
                                                                    items: [
                                                                      const PopupMenuItem(
                                                                        value: 'modifier_ligne',
                                                                        child: Text(
                                                                          'Modifier',
                                                                          style: TextStyle(fontSize: 12),
                                                                        ),
                                                                      ),
                                                                      const PopupMenuItem(
                                                                        value: 'supprimer_ligne',
                                                                        child: Text(
                                                                          'Supprimer',
                                                                          style: TextStyle(fontSize: 12),
                                                                        ),
                                                                      ),
                                                                    ],
                                                                  ).then((value) {
                                                                    if (value == 'modifier_ligne') {
                                                                      _chargerLigneArticle(index);
                                                                    } else if (value == 'supprimer_ligne') {
                                                                      _supprimerLigne(index);
                                                                    }
                                                                  });
                                                                },
                                                          child: Container(
                                                            height: 18,
                                                            decoration: BoxDecoration(
                                                              color: _selectedRowIndex == index
                                                                  ? Colors.blue[300]
                                                                  : (index % 2 == 0
                                                                        ? Colors.white
                                                                        : Colors.grey[50]),
                                                            ),
                                                            child: Row(
                                                              children: [
                                                                Container(
                                                                  width: 50,
                                                                  alignment: Alignment.center,
                                                                  decoration: const BoxDecoration(
                                                                    border: Border(
                                                                      right: BorderSide(
                                                                        color: Colors.grey,
                                                                        width: 1,
                                                                      ),
                                                                      bottom: BorderSide(
                                                                        color: Colors.grey,
                                                                        width: 1,
                                                                      ),
                                                                    ),
                                                                  ),
                                                                  child: IconButton(
                                                                    icon: const Icon(Icons.close, size: 12),
                                                                    onPressed: _statutAchatActuel == 'JOURNAL'
                                                                        ? null
                                                                        : () => _supprimerLigne(index),
                                                                    padding: EdgeInsets.zero,
                                                                    constraints: const BoxConstraints(),
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 3,
                                                                  child: Container(
                                                                    padding: const EdgeInsets.only(left: 4),
                                                                    alignment: Alignment.centerLeft,
                                                                    decoration: const BoxDecoration(
                                                                      border: Border(
                                                                        right: BorderSide(
                                                                          color: Colors.grey,
                                                                          width: 1,
                                                                        ),
                                                                        bottom: BorderSide(
                                                                          color: Colors.grey,
                                                                          width: 1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    child: Text(
                                                                      ligne['designation'] ?? '',
                                                                      style: const TextStyle(fontSize: 11),
                                                                      overflow: TextOverflow.ellipsis,
                                                                    ),
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Container(
                                                                    padding: const EdgeInsets.symmetric(
                                                                      horizontal: 4,
                                                                    ),
                                                                    alignment: Alignment.center,
                                                                    decoration: const BoxDecoration(
                                                                      border: Border(
                                                                        right: BorderSide(
                                                                          color: Colors.grey,
                                                                          width: 1,
                                                                        ),
                                                                        bottom: BorderSide(
                                                                          color: Colors.grey,
                                                                          width: 1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    child: Text(
                                                                      ligne['unites'] ?? '',
                                                                      style: const TextStyle(fontSize: 11),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Container(
                                                                    padding: const EdgeInsets.symmetric(
                                                                      horizontal: 4,
                                                                    ),
                                                                    alignment: Alignment.center,
                                                                    decoration: const BoxDecoration(
                                                                      border: Border(
                                                                        right: BorderSide(
                                                                          color: Colors.grey,
                                                                          width: 1,
                                                                        ),
                                                                        bottom: BorderSide(
                                                                          color: Colors.grey,
                                                                          width: 1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    child: Text(
                                                                      (ligne['quantite'] as double?)
                                                                              ?.round()
                                                                              .toString() ??
                                                                          '0',
                                                                      style: const TextStyle(fontSize: 11),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 2,
                                                                  child: Container(
                                                                    padding: const EdgeInsets.symmetric(
                                                                      horizontal: 4,
                                                                    ),
                                                                    alignment: Alignment.center,
                                                                    decoration: const BoxDecoration(
                                                                      border: Border(
                                                                        right: BorderSide(
                                                                          color: Colors.grey,
                                                                          width: 1,
                                                                        ),
                                                                        bottom: BorderSide(
                                                                          color: Colors.grey,
                                                                          width: 1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    child: Text(
                                                                      NumberUtils.formatNumber(
                                                                        ligne['prixUnitaire']?.toDouble() ??
                                                                            0,
                                                                      ),
                                                                      style: const TextStyle(fontSize: 11),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 2,
                                                                  child: Container(
                                                                    padding: const EdgeInsets.symmetric(
                                                                      horizontal: 4,
                                                                    ),
                                                                    alignment: Alignment.center,
                                                                    decoration: const BoxDecoration(
                                                                      border: Border(
                                                                        right: BorderSide(
                                                                          color: Colors.grey,
                                                                          width: 1,
                                                                        ),
                                                                        bottom: BorderSide(
                                                                          color: Colors.grey,
                                                                          width: 1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    child: Text(
                                                                      NumberUtils.formatNumber(
                                                                        ligne['montant']?.toDouble() ?? 0,
                                                                      ),
                                                                      style: const TextStyle(fontSize: 11),
                                                                    ),
                                                                  ),
                                                                ),
                                                                Expanded(
                                                                  flex: 1,
                                                                  child: Container(
                                                                    alignment: Alignment.center,
                                                                    decoration: const BoxDecoration(
                                                                      border: Border(
                                                                        bottom: BorderSide(
                                                                          color: Colors.grey,
                                                                          width: 1,
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    child: Text(
                                                                      ligne['depot'] ?? '',
                                                                      style: const TextStyle(fontSize: 11),
                                                                    ),
                                                                  ),
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      );
                                                    },
                                                  ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),

                                  // Bottom section
                                  Container(
                                    color: const Color(0xFFE6E6FA),
                                    padding: const EdgeInsets.all(8),
                                    child: Row(
                                      children: [
                                        // Left side - Payment info
                                        Expanded(
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Row(
                                                children: [
                                                  const Text(
                                                    'Mode de paiement',
                                                    style: TextStyle(fontSize: 12),
                                                  ),
                                                  const SizedBox(width: 8),
                                                  SizedBox(
                                                    width: 120,
                                                    height: 25,
                                                    child: DropdownButtonFormField<String>(
                                                      alignment: AlignmentGeometry.center,
                                                      initialValue: _selectedModePaiement,
                                                      decoration: const InputDecoration(
                                                        border: OutlineInputBorder(),
                                                        contentPadding: EdgeInsets.symmetric(
                                                          horizontal: 4,
                                                          vertical: 2,
                                                        ),
                                                      ),
                                                      items: _modesPaiement
                                                          .where((mp) => mp.mp == 'A crédit')
                                                          .map((mp) {
                                                            return DropdownMenuItem<String>(
                                                              alignment: AlignmentGeometry.center,
                                                              value: mp.mp,
                                                              child: Text(
                                                                mp.mp,
                                                                style: const TextStyle(fontSize: 12),
                                                              ),
                                                            );
                                                          })
                                                          .toList(),
                                                      onChanged: (value) {
                                                        setState(() {
                                                          _selectedModePaiement = value;
                                                        });
                                                      },
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              const SizedBox(height: 4),
                                              Row(
                                                children: [
                                                  const Text(
                                                    'Echéance (Date)',
                                                    style: TextStyle(fontSize: 12),
                                                  ),
                                                  const SizedBox(width: 8),
                                                  SizedBox(
                                                    width: 137,
                                                    height: 25,
                                                    child: TextField(
                                                      cursorHeight: 16,
                                                      controller: _echeanceController,
                                                      textAlign: TextAlign.center,
                                                      readOnly: true,
                                                      decoration: const InputDecoration(
                                                        border: OutlineInputBorder(),
                                                        contentPadding: EdgeInsets.symmetric(
                                                          horizontal: 4,
                                                          vertical: 2,
                                                        ),
                                                        suffixIcon: Icon(Icons.calendar_today, size: 16),
                                                      ),
                                                      onTap: () async {
                                                        final date = await showDatePicker(
                                                          context: context,
                                                          initialDate: DateTime.now(),
                                                          firstDate: DateTime(2000),
                                                          lastDate: DateTime(2100),
                                                        );
                                                        if (date != null) {
                                                          _echeanceController.text =
                                                              app_date.AppDateUtils.formatDate(date);
                                                        }
                                                      },
                                                    ),
                                                  ),
                                                ],
                                              ),
                                              const SizedBox(height: 4),
                                              Row(
                                                children: [
                                                  const Text(
                                                    'Echéance (Jours)',
                                                    style: TextStyle(fontSize: 12),
                                                  ),
                                                  const SizedBox(width: 8),
                                                  SizedBox(
                                                    width: 135,
                                                    height: 25,
                                                    child: TextField(
                                                      style: const TextStyle(fontSize: 14),
                                                      cursorHeight: 14,
                                                      controller: _echeanceJoursController,
                                                      focusNode: _echeanceJoursFocusNode,
                                                      textAlign: TextAlign.center,
                                                      decoration: const InputDecoration(
                                                        border: OutlineInputBorder(),
                                                        contentPadding: EdgeInsets.symmetric(
                                                          horizontal: 4,
                                                          vertical: 2,
                                                        ),
                                                        hintText: 'Ctrl+J',
                                                        hintStyle: TextStyle(
                                                          color: Colors.grey,
                                                          fontSize: 12,
                                                        ),
                                                        suffixIcon: Icon(Icons.access_time_rounded, size: 16),
                                                      ),
                                                    ),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),

                                        const SizedBox(width: 32),

                                        // Right side - Totals
                                        Column(
                                          crossAxisAlignment: CrossAxisAlignment.end,
                                          children: [
                                            Row(
                                              children: [
                                                const Text('Total TTC', style: TextStyle(fontSize: 12)),
                                                const SizedBox(width: 16),
                                                SizedBox(
                                                  width: 100,
                                                  height: 25,
                                                  child: TextField(
                                                    controller: _totalTTCController,
                                                    textAlign: TextAlign.right,
                                                    readOnly: true,
                                                    decoration: const InputDecoration(
                                                      border: OutlineInputBorder(),
                                                      contentPadding: EdgeInsets.symmetric(
                                                        horizontal: 4,
                                                        vertical: 2,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                            const SizedBox(height: 4),
                                            Row(
                                              children: [
                                                const Text(
                                                  'Total en FMG',
                                                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
                                                ),
                                                const SizedBox(width: 16),
                                                Container(
                                                  alignment: Alignment.centerRight,
                                                  constraints: const BoxConstraints(
                                                    minWidth: 100,
                                                    maxWidth: 150,
                                                  ),
                                                  height: 25,
                                                  child: TextField(
                                                    controller: _totalFMGController,
                                                    textAlign: TextAlign.right,
                                                    readOnly: true,
                                                    decoration: const InputDecoration(
                                                      border: OutlineInputBorder(),
                                                      contentPadding: EdgeInsets.symmetric(
                                                        horizontal: 4,
                                                        vertical: 2,
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),

                                  // Action buttons
                                  Container(
                                    width: double.infinity,
                                    decoration: const BoxDecoration(
                                      borderRadius: BorderRadius.only(
                                        bottomLeft: Radius.circular(16),
                                        bottomRight: Radius.circular(16),
                                      ),
                                      color: Color(0xFFFFB6C1),
                                    ),
                                    padding: const EdgeInsets.all(8),
                                    child: SingleChildScrollView(
                                      child: Row(
                                        spacing: 4,
                                        children: [
                                          Tooltip(
                                            message: 'Achat précédent (F1)',
                                            child: SizedBox(
                                              width: 30,
                                              height: 30,
                                              child: ElevatedButton(
                                                onPressed: _achatsNumbers.isNotEmpty
                                                    ? () => _naviguerAchat(false)
                                                    : null,
                                                style: ElevatedButton.styleFrom(
                                                  padding: EdgeInsets.zero,
                                                  minimumSize: const Size(30, 30),
                                                ),
                                                child: const Icon(Icons.arrow_back_ios, size: 14),
                                              ),
                                            ),
                                          ),
                                          Tooltip(
                                            message: 'Achat suivant (F2)',
                                            child: SizedBox(
                                              width: 30,
                                              height: 30,
                                              child: ElevatedButton(
                                                onPressed: _achatsNumbers.isNotEmpty
                                                    ? () => _naviguerAchat(true)
                                                    : null,
                                                style: ElevatedButton.styleFrom(
                                                  padding: EdgeInsets.zero,
                                                  minimumSize: const Size(30, 30),
                                                ),
                                                child: const Icon(Icons.arrow_forward_ios, size: 14),
                                              ),
                                            ),
                                          ),
                                          Tooltip(
                                            message: 'Importer lignes d\'achat',
                                            child: ElevatedButton(
                                              onPressed: _statutAchatActuel == 'JOURNAL'
                                                  ? null
                                                  : _importerLignesAchat,
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: Colors.orange,
                                                foregroundColor: Colors.white,
                                                minimumSize: const Size(60, 30),
                                              ),
                                              child: const Text(
                                                'Importer lignes',
                                                style: TextStyle(fontSize: 12),
                                              ),
                                            ),
                                          ),
                                          if (_isExistingPurchase) ...[
                                            Tooltip(
                                              message: 'Créer nouveau (Ctrl+N)',
                                              child: ElevatedButton(
                                                onPressed: _creerNouvelAchat,
                                                style: ElevatedButton.styleFrom(
                                                  minimumSize: const Size(60, 30),
                                                ),
                                                child: const Text(
                                                  'Créer (Ctrl+N)',
                                                  style: TextStyle(fontSize: 12),
                                                ),
                                              ),
                                            ),
                                            if (_statutAchatActuel == 'BROUILLARD') ...[
                                              Tooltip(
                                                message: 'Valider l\'achat (F3)',
                                                child: ElevatedButton(
                                                  onPressed: _validerAchatBrouillard,
                                                  style: ElevatedButton.styleFrom(
                                                    backgroundColor: Colors.green,
                                                    foregroundColor: Colors.white,
                                                    minimumSize: const Size(80, 30),
                                                  ),
                                                  child: const Text(
                                                    'Valider l\'achat (F3)',
                                                    style: TextStyle(fontSize: 12),
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ],
                                          if (_isExistingPurchase) ...[
                                            Tooltip(
                                              message: 'Contre-passer (Ctrl+D)',
                                              child: ElevatedButton(
                                                onPressed: _statutAchatActuel == 'CONTRE-PASSé'
                                                    ? null
                                                    : _contrePasserAchat,
                                                style: ElevatedButton.styleFrom(
                                                  minimumSize: const Size(80, 30),
                                                ),
                                                child: const Text(
                                                  'Contre Passer',
                                                  style: TextStyle(fontSize: 12),
                                                ),
                                              ),
                                            ),
                                          ],
                                          Tooltip(
                                            message: _isExistingPurchase
                                                ? 'Modifier (Ctrl+S)'
                                                : 'Enregistrer (Ctrl+S)',
                                            child: ElevatedButton(
                                              onPressed:
                                                  _isExistingPurchase &&
                                                      (_statutAchatActuel == 'JOURNAL' ||
                                                          _statutAchatActuel == 'CONTRE-PASSé')
                                                  ? null
                                                  : (_isExistingPurchase ? _modifierAchat : _validerAchat),
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: _isExistingPurchase
                                                    ? Colors.blue
                                                    : Colors.green,
                                                foregroundColor: Colors.white,
                                                minimumSize: const Size(60, 30),
                                              ),
                                              child: Text(
                                                _isExistingPurchase
                                                    ? 'Modifier(Ctrl+S)'
                                                    : 'Enregistrer (Ctrl+S)',
                                                style: const TextStyle(fontSize: 12),
                                              ),
                                            ),
                                          ),
                                          const Spacer(),
                                          PopupMenuButton<String>(
                                            style: const ButtonStyle(
                                              padding: WidgetStateProperty.fromMap({
                                                WidgetState.hovered: EdgeInsets.all(0),
                                                WidgetState.focused: EdgeInsets.all(0),
                                                WidgetState.pressed: EdgeInsets.all(0),
                                              }),
                                            ),
                                            menuPadding: const EdgeInsets.all(2),
                                            initialValue: _selectedFormat,
                                            onSelected: (String format) {
                                              setState(() {
                                                _selectedFormat = format;
                                              });
                                            },
                                            itemBuilder: (BuildContext context) => [
                                              const PopupMenuItem(
                                                value: 'A4',
                                                child: Text('Format A4', style: TextStyle(fontSize: 12)),
                                              ),
                                              const PopupMenuItem(
                                                value: 'A5',
                                                child: Text('Format A5', style: TextStyle(fontSize: 12)),
                                              ),
                                              const PopupMenuItem(
                                                value: 'A6',
                                                child: Text('Format A6', style: TextStyle(fontSize: 12)),
                                              ),
                                            ],
                                            child: Container(
                                              constraints: const BoxConstraints(
                                                minWidth: 60,
                                                minHeight: 18,
                                                maxHeight: 30,
                                              ),
                                              padding: const EdgeInsets.symmetric(
                                                horizontal: 12,
                                                vertical: 3,
                                              ),
                                              decoration: BoxDecoration(
                                                color: Colors.brown,
                                                borderRadius: BorderRadius.circular(12),
                                              ),
                                              child: Row(
                                                mainAxisSize: MainAxisSize.min,
                                                children: [
                                                  const Icon(
                                                    Icons.format_size,
                                                    color: Colors.white,
                                                    size: 16,
                                                  ),
                                                  const SizedBox(width: 4),
                                                  Text(
                                                    _selectedFormat,
                                                    style: const TextStyle(color: Colors.white, fontSize: 12),
                                                  ),
                                                  const SizedBox(width: 4),
                                                  const Icon(
                                                    Icons.arrow_drop_down,
                                                    color: Colors.white,
                                                    size: 16,
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          Tooltip(
                                            message: 'Aperçu BR',
                                            child: ElevatedButton(
                                              onPressed: _lignesAchat.isNotEmpty ? _ouvrirApercuBR : null,
                                              style: ElevatedButton.styleFrom(
                                                minimumSize: const Size(70, 30),
                                              ),
                                              child: const Text('Aperçu BR', style: TextStyle(fontSize: 12)),
                                            ),
                                          ),
                                          Tooltip(
                                            message: 'Imprimer BR (Ctrl+P)',
                                            child: ElevatedButton(
                                              onPressed: _lignesAchat.isNotEmpty
                                                  ? _imprimerBonReception
                                                  : null,
                                              style: ElevatedButton.styleFrom(
                                                backgroundColor: Colors.purple,
                                                foregroundColor: Colors.white,
                                                minimumSize: const Size(70, 30),
                                              ),
                                              child: const Row(
                                                children: [
                                                  Icon(Icons.print, size: 16),
                                                  SizedBox(width: 8),
                                                  Text(
                                                    "Imprimer BR (Ctrl+P)",
                                                    style: TextStyle(fontSize: 12),
                                                  ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          const Spacer(),
                                          Tooltip(
                                            message: 'Fermer (Echap)',
                                            child: ElevatedButton(
                                              onPressed: () => Navigator.of(context).pop(),
                                              style: ElevatedButton.styleFrom(
                                                minimumSize: const Size(60, 30),
                                              ),
                                              child: const Text('Fermer', style: TextStyle(fontSize: 12)),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
